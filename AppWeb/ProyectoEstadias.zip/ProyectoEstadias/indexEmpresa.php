<!doctype html>

<?php
session_start();

?>
<html lang="en">

    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <title>DarEn BLOG || HOME</title>
        <link rel="icon" href="img/favicon.png">
        <!-- Bootstrap CSS -->
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <!-- animate CSS -->
        <link rel="stylesheet" href="css/animate.css">
        <!-- owl carousel CSS -->
        <link rel="stylesheet" href="css/owl.carousel.min.css">
        <!-- themify CSS -->
        <link rel="stylesheet" href="css/themify-icons.css">
        <!-- flaticon CSS -->
        <link rel="stylesheet" href="css/liner_icon.css">
        <link rel="stylesheet" href="css/search.css">
        <!-- style CSS -->
        <link rel="stylesheet" href="css/style.css">
    </head>
<?php
            if(isset($_SESSION['Alumno']) || isset($_SESSION['Personal'] ) || isset($_SESSION['UsuarioNormal'] ) ){
            ?>

    <body>
        <!--::header part start::-->
        <header class="main_menu">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-12">
                        <nav class="navbar navbar-expand-lg navbar-light">
                            <a class="navbar-brand" href="index.html"> <img src="login/images/logo_p.png"  alt="logo"> </a>
                            <button class="navbar-toggler" type="button" data-toggle="collapse"
                                    data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                                    aria-expanded="false" aria-label="Toggle navigation">
                                <span class="navbar-toggler-icon"></span>
                            </button>

                            <div class="collapse navbar-collapse main-menu-item justify-content-center"
                                 id="navbarSupportedContent">
                              <ul class="navbar-nav">
                                    <li class="nav-item active">
                                         <?php 
                                    
                                     if ("Alumno"==$_SESSION['tipoUser']) {
                                         
                                    
                                    
?>  
                                         <li class="nav-item">
                                    <a class="nav-link" href="index3.php">Home</a>
                                     </li>
                                         <li class="nav-item">
                                        <a class="nav-link" href="formularios/PropuestaEmpresa.php">Propuesta Empresa</a>
                                    </li>
                                    
                                <?php 
                                     } elseif ("Personal"==$_SESSION['tipoUser']) {
                                        
                                 ?>
                                     <a class="nav-link" href="index2.php">Home</a>
                                <?php    
                                    } elseif ("UsuarioNormal"==$_SESSION['tipoUser']) {
                                        
                                 ?>
                                     <a class="nav-link" href="index1.php">Home</a>
                                <?php    
                                    }
                                ?>
                                    </li>
                                   
                                      <?php
                                    if  ("Personal"==$_SESSION['tipoUser']) {
                                        
                                 
                                    ?>
                                      <li class="nav-item">
                                          <a class="nav-link" href="formularios/RegistroU.php">Registro de usuarios</a>
                                    </li>
                                      <li class="nav-item">
                                          <a class="nav-link" href="PropuestasEmp.php">Propuestas de Empresa</a>
                                    </li>
                                      <li class="nav-item">
                                          <a class="nav-link" href="Postulaciones.php">Postulaciones</a>
                                    </li>
                                   <?php
                                      }
                                   ?> 
                                </ul>
                            </div>
                          <div class="header_social_icon d-none d-sm-block">
                                <ul>
                                     <li><a href="php_files/logout.php"a class="d-none d-lg-block">Cerrar Sesion <i class="ti-lock"></i></a></li>
                                </ul>
                            </div>
                        </nav>
                    </div>
                </div>
            </div>
        </header>
        <!-- Header part end-->
        <h1 style="text-align: center">Empresas</h1>

        <!-- banner post end-->

        <!-- feature_post start-->

        <!-- border_top start-->
        <div class="border_top"></div>
        <!-- border_top end-->

        <!-- feature_post start-->
        <section class="catagory_post">
           
            <div class="container">
                <div class="row">
                     
                           <?php 
                            require_once './php_files/Conecta.php';
                            
                               $con= Conectar();
                                if("Personal"==$_SESSION['tipoUser'] || "UsuarioNormal"==$_SESSION['tipoUser'] ){
                                    require_once './php_files/lib_empresas.php';
                             
                          
                             
                              $result= muestraAllEmpresas();
                             
                         } else {
                                       require_once './php_files/lib_empresas.php';
                              $result= muestraEmpresasCarrera($_SESSION['usuario_id']);
                         }      
                              
                              while ($res= mysqli_fetch_array($result)){
                               
                                  
                              
                            ?>
                     <div class="col-sm-6 col-lg-4">
                  
                        <div class="single_catagory_post post_2">
                            <div class="category_post_img">
                                
                                 <?php echo '<a href="Empresa.php?id='.$res['id_emp'].'"><img src="'.$res['imagen_empresa'].'"; height="500" width="500"></a>'?>
                                
                                    
                                    <?php echo '<a href="Empresa.php?id='.$res['id_emp'].'" class="category_btn">'.$res['nombre_cr'].'<br> Area: '.$res['Area'].'</a>'; ?>>
                            </div>
                            <div class="post_text_1 pr_30">
                                    <?php echo "<a href=Empresa.php?id=".$res['id_emp']."><h1>".$res['nombre_e']."</h1></a>";?>
                                   
                                    
                                    <p><?php echo "<a href=Empresa.php?id=".$res['id_emp']."><h2>Ubicacion: ".$res['ubicacion']."</h2></a>";?>
                                    </p>
                                <div class="post_icon">
                                    <ul>
                                        <li><i class="ti-calendar"></i><strong>Fecha que se subio: <?php  echo $res['fecha_upload']?> </strong></li>
                                       
                                    </ul>
                                </div>
                                    
                                   
                            </div>
                        </div>
                    </div>
                    <?php 
                            }
                            ?>
                    
                    
                    
                   
                </div>
            </div>
        </section>
        <!-- feature_post end-->

        <!-- border_top start-->
        <div class="border_top"></div>
        <!-- border_top end-->


        <!-- footer part start-->
         <footer class="footer-area">
            <div class="container">
                <center>
                <div class="row">
                    <div class="col-xl-4 col-md-4 col-sm-6">
                        <div class="single-footer-widget footer_1">
                            <img src="login/images/group digital logo_p.png" alt="">
                        </div>
                    </div>
                    <div class="col-xl-4 col-md-4 col-sm-6">
                        <div class="single-footer-widget footer_2">
                            <h4>Contactanos</h4>
                            <div class="contact_info">
                                <span class="ti-home"></span>
                                <h5>Av. Universidad Tecnológica</h5>
                                <p>#1000, Col.Tierra Negra Xicotepec de Juárez, Puebla C.P.73080</p>
                            </div>
                            <div class="contact_info">
                                <span class="ti-headphone-alt"></span>
                                <h5>01 (764) 764 5240 y 764 5252</h5>
                            </div>
                        </div>
                    </div>
                </div>
                </center>
                <div class="row align-items-center">
                    <div class="col-lg-12">
                        <div class="copyright_part_text text-center">
                            <p class="footer-text m-0"><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                                Copyright &copy;<script>document.write(new Date().getFullYear());</script> <i class="ti-heart" aria-hidden="true"></i> por <a href="https://colorlib.com" target="_blank">GROUP DIGITAL</a>
                                <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. --></p>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
        <!-- footer part end-->
     <?php
            }else{
                header("Location: http://localhost/ProyectoEstadias/Login.php ");
            }
            ?>
        <!-- jquery plugins here-->
        <!-- jquery -->
        <script src="js/jquery-1.12.1.min.js"></script>
        <!-- popper js -->
        <script src="js/popper.min.js"></script>
        <!-- bootstrap js -->
        <script src="js/bootstrap.min.js"></script>
        <!-- custom js -->
        <script src="js/custom.js"></script>
    </body>

</html>