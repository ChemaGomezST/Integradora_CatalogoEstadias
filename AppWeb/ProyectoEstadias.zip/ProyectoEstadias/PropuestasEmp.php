<?php
session_start();

include 'php_files/lib_empresas.php';
$buscar = false;
if($_POST){
if ($_POST['btn'] == "buscar") {
    $idPr = $_POST['idPostulacion'];
    $result = buscarPro($idPr);
    if ($result->num_rows > 0) {
        $buscar = true;
        while ($fila = $result->fetch_assoc()) {
            $id = $fila['id'];
            $nomEm = $fila['Nombre_empresa'];
            $cont = $fila['Contacto'];
            $vac = $fila['Total_vacantes'];
            $nivel = $fila['Nivel'];
            $nomCom = $fila['nombre_completo'];
            $matr = $fila['matricula'];
        }
    }
} else if ($_POST['btn'] == "elimina") {
    echo "<script type='text/javascript'>alert('la matricula a eliminar es " . $_POST['rm'] . "');</script>";
    eliminar($_POST['rm']);
}
}
?>
<!DOCTYPE html>
<html lang="en">

    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <title>Estadias</title>
        <link rel="icon" href="img/favicon.png">
        <!-- Bootstrap CSS -->
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <!-- animate CSS -->
        <link rel="stylesheet" href="css/animate.css">
        <!-- owl carousel CSS -->
        <link rel="stylesheet" href="css/owl.carousel.min.css">
        <!-- themify CSS -->
        <link rel="stylesheet" href="css/themify-icons.css">
        <!-- flaticon CSS -->
        <link rel="stylesheet" href="css/liner_icon.css">
        <link rel="stylesheet" href="css/search.css">
        <!-- swiper CSS -->
        <link rel="stylesheet" href="css/slick.css">
        <!-- style CSS -->
        <link rel="stylesheet" href="css/style.css">
    </head>

    <body>
        <!--::header part start::-->
        <header class="main_menu">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-12">
                        <nav class="navbar navbar-expand-lg navbar-light">
                            <a class="navbar-brand" href="index.html"> <img src="login/images/logo_p.png" alt="logo"> </a>
                            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
                                    aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                                <span class="navbar-toggler-icon"></span>
                            </button>

                            <div class="collapse navbar-collapse main-menu-item justify-content-center" id="navbarSupportedContent">
                                <ul class="navbar-nav">
                                    <li class="nav-item active">
                                        <a class="nav-link" href="index3.php">Inicio</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="indexEmpresa.php">Empresas</a>
                                    </li>
                                    <li class="nav-item">
                                          <a class="nav-link" href="formularios/RegistroU.php">Registro de usuarios</a>
                                    </li>
                                      <li class="nav-item">
                                          <a class="nav-link" href="Registro_Empresas.php">Registro de Empresas</a>
                                    </li>
                                      <li class="nav-item">
                                          <a class="nav-link" href="Postulaciones.php">Postulaciones</a>
                                    </li>
                                </ul>
                            </div>
                            <div class="header_social_icon d-none d-sm-block">
                                <ul>
                                    <li><a href="php_files/logout.php"a class="d-none d-lg-block">Cerrar Sesion <i class="ti-lock"></i></a></li>
                                </ul>
                            </div>
                        </nav>
                    </div>
                </div>
            </div>
        </header>
        <!-- Header part end-->
        <?php
        if (isset($_SESSION['Personal'])) {
            ?>

            <!-- breadcrumb start-->
            <section class="breadcrumb breadcrumb_bg">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="breadcrumb_iner text-center">
                                <div class="breadcrumb_iner_item">
                                    <h2>Propuestas de empresas</h2>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- breadcrumb start-->

            <section>
                <br>

                <div class="container col-md-10">
                    <div class="container-fluid" style="align-content: space-around;">
                        <div class="form-group col-sm-8">
                            <div class="help-block with-errors"></div>
                            <form action="PropuestasEmp.php" method="post" class="form-inline">
                                <strong><label for="idPostulacion">Buscar Propuesta</label></strong>
                                <input type="text" class="form-control" name="idPostulacion" id="idPostulacion"/>
                                <button type="submit" name="btn" value="buscar" class="btn btn-success">Buscar</button>                   
                              
                            </form>
                        </div>  
                    </div>          
                    <table class="table table-hover" style="border-top-color: #4DBE42;">
                        <thead style="background-color: #34ce57">
                            <tr>
                                <td><strong>Acción</strong></td>
                                <td><strong>Num. Registro</strong></td>
                                <td><strong>Nombre Empresa</strong></td>
                                <td><strong>Contacto</strong></td>
                                <td><strong>Total de Vacantes</strong></td>
                                <td><strong>Nivel</strong></td>
                                <td><strong>Quien la propuso</strong></td>
                                <td><strong>Matricula</strong></td>
                            </tr>
                        </thead>
                        <tbody><!--fetch_asoc es un arreglo asociativo-->
                            <?php
                            if ($buscar == true) {
                                ?>
                                <tr>
                                    <td>
                                        <form action="PropuestasEmp.php" method="post">
                                            <input type="radio" name="rm" value="<?php echo $id ?>">
                                            <button type="submit" value="elimina" name="btn" class="btn-danger">Eliminar</button>
                                        </form>
                                    </td>
                                    
                                    <td><?php echo $id ?></td>
                                    <td><?php echo $nomEm ?></td>
                                    <td><?php echo $cont ?></td>
                                    <td><?php echo $vac ?></td>
                                    <td><?php echo $nivel ?></td>
                                    <td><?php echo $nomCom ?></td>
                                    <td><?php echo $matr ?></td>
                                    

                                </tr>
                                <?php
                            } else {

                                $result = muestraProEmpresas();
                                if ($result->num_rows > 0) {
                                    while ($fila = $result->fetch_assoc()) {
                                        ?>
                                        <tr>
                                            <td>
                                                <form action="PropuestasEmp.php" method="post">
                                                    <input type="radio" name="rm" value="<?php echo $fila['id']; ?>">
                                                    <button type="submit" value="elimina" name="btn" class="btn-danger">Eliminar</button>
                                                </form>
                                            </td>

                                            <td><?php echo $fila['id']; ?></td>
                                            <td><?php echo $fila['Nombre_empresa']; ?></td>
                                            <td><?php echo $fila['Contacto']; ?></td>
                                            <td><?php echo $fila['Total_vacantes']; ?></td>
                                            <td><?php echo $fila['Nivel']; ?></td>
                                            <td><?php echo $fila['nombre_completo']; ?></td>
                                            <td><?php echo $fila['matricula']; ?></td>
                                            


                                        </tr>
                                        <?php
                                    }
                                }
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
    <!--            <script type="text/javascript">
                function Preguntar(idP){
                    if(confirm('Se eliminara el registro'+idP+'?'))
                    {
                    
                    window.location.href="./php_files/lib_empresas.php?id=" + idP;
                }
            </script>-->
        </section>


        <?php
    } else {
        header("Location: http://localhost/ProyectoEstadias/Login.php ");
    }
    ?>
    <!-- footer part end-->
    
    <!-- jquery plugins here-->
    <!-- jquery -->
    <script src="js/jquery-1.12.1.min.js"></script>
    <script src="js/ajax-jquery.min.js.js"></script>
    <!-- popper js -->
    <script src="js/popper.min.js"></script>
    <!-- bootstrap js -->
    <script src="js/bootstrap.min.js"></script>
    <!-- particles js -->
    <script src="js/contact.js"></script>
    <!-- ajaxchimp js -->
    <script src="js/jquery.ajaxchimp.min.js"></script>
    <!-- validate js -->
    <script src="js/jquery.validate.min.js"></script>
    <!-- form js -->
    <script src="js/jquery.form.js"></script>
    <script src="js/mail-script.js"></script>
    <!-- custom js -->
    <script src="js/custom.js"></script>
</body>

</html>
