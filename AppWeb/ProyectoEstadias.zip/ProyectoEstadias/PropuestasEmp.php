<?php
session_start();
include 'php_files/lib_empresas.php';
if ($_POST) {
    if ($_POST['btn'] == "actualizar") {
         $vincEm=$_POST['estatusVin'];
         $estatusEmp=$_POST['estatusEmp'];
         $idEmp=$_POST['empresaID'];
          ActualizaEstatus($vincEm,$estatusEmp,$idEmp);
    }
}




$buscar = false;
if($_POST){
if ($_POST['btn'] == "buscar") {
    $idProEmp = $_POST['idPostu'];
    $result = buscarProEmp($idProEmp);
    if ($result->num_rows > 0) {
        $buscar = true;
        while ($fila = $result->fetch_assoc()) {
            $id = $fila['id_emp'];
            $nomEm = $fila['nombre_e'];
            $imgEmp = $fila['imagen_empresa'];
            $tamaEmp = $fila['Tamaño'];
            $caractEmp = $fila['Caracteristicas'];
            $infoEmp = $fila['Informacion'];
            $vincEmp = $fila['Vinculada'];
            $rfcEmp = $fila['RFC'];
            $estatusEmp = $fila['estatus'];
            $nomcr = $fila['nombre_cr'];
            $carEmp= $fila['Area'];
        }
    }
} else if ($_POST['btn'] == "elimina") {
    echo "<script type='text/javascript'>alert('la empresa que se eliminara  " . $_POST['rm'] . "');</script>";
    eliminarEmp($_POST['rm']);
}
}
?>
<!DOCTYPE html>
<html lang="en">

    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <title>Estadias</title>
        <link rel="icon" href="img/favicon.png">
        <!-- Bootstrap CSS -->
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <!-- animate CSS -->
        <link rel="stylesheet" href="css/animate.css">
        <!-- owl carousel CSS -->
        <link rel="stylesheet" href="css/owl.carousel.min.css">
        <!-- themify CSS -->
        <link rel="stylesheet" href="css/themify-icons.css">
        <!-- flaticon CSS -->
        <link rel="stylesheet" href="css/liner_icon.css">
        <link rel="stylesheet" href="css/search.css">
        <!-- swiper CSS -->
        <link rel="stylesheet" href="css/slick.css">
        <!-- style CSS -->
        <link rel="stylesheet" href="css/style.css">
    </head>

    <body>
        <!--::header part start::-->
        <header class="main_menu">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-12">
                        <nav class="navbar navbar-expand-lg navbar-light">
                            <a class="navbar-brand" href="index.html"> <img src="login/images/logo_p.png" alt="logo"> </a>
                            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
                                    aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                                <span class="navbar-toggler-icon"></span>
                            </button>

                            <div class="collapse navbar-collapse main-menu-item justify-content-center" id="navbarSupportedContent">
                                <ul class="navbar-nav">
                                    <li class="nav-item active">
                                        <a class="nav-link" href="index3.php">Inicio</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="indexEmpresa.php">Empresas</a>
                                    </li>
                                    <li class="nav-item">
                                          <a class="nav-link" href="formularios/RegistroU.php">Registro de usuarios</a>
                                    </li>
                                      <li class="nav-item">
                                          <a class="nav-link" href="Registro_Empresas.php">Registro de Empresas</a>
                                    </li>
                                      <li class="nav-item">
                                          <a class="nav-link" href="Postulaciones.php">Postulaciones</a>
                                    </li>
                                </ul>
                            </div>
                            <div class="header_social_icon d-none d-sm-block">
                                <ul>
                                    <li><a href="php_files/logout.php"a class="d-none d-lg-block">Cerrar Sesion <i class="ti-lock"></i></a></li>
                                </ul>
                            </div>
                        </nav>
                    </div>
                </div>
            </div>
        </header>
        <!-- Header part end-->
        <?php
        if (isset($_SESSION['Personal'])) {
            ?>

            <!-- breadcrumb start-->
            <section class="breadcrumb breadcrumb_bg">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="breadcrumb_iner text-center">
                                <div class="breadcrumb_iner_item">
                                    <h2>Propuestas de empresas</h2>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- breadcrumb start-->

            <section>
                <br>

                <div class="container col-md-8 offset-1 left-padding">
                    <div class="container-fluid" style="align-content: space-around;">
                        <div class="form-group col-sm-8">
                            <div class="help-block with-errors"></div>
                            <form action="PropuestasEmp.php" method="post" class="form-inline">
                                <strong><label for="idPostulacion">Buscar Propuesta</label></strong>
                                <input type="text" class="form-control" name="idPostu" id="idPostu"/>
                                <button type="submit" name="btn" value="buscar" class="btn btn-success">Buscar</button>                   
                              
                            </form>
                        </div>  
                    </div>          
                    <center><table class="table table-hover col-md-auto" style="border-top-color: #4DBE42;">
                        <thead style="background-color: #34ce57">
                            <tr>
                                <td  style="padding: 10px;"><strong>Acción</strong></td>
                                <td  style="padding: 10px;"><strong>Num. Registro</strong></td>
                                <td  style="padding: 10px;"><strong>Nombre Empresa</strong></td>
                                <td  style="padding: 10px;"><strong>Imagen de Empresa</strong></td>
                                <td  style="padding: 10px;"><strong>Tamaño</strong></td>
                                <td  style="padding: 10px;"><strong>Caracteristicas</strong></td>
                                <td  style="padding: 10px;"><strong>Información</strong></td>
                                <td  style="padding: 10px;"><strong>RFC</strong></td>
                                <td  style="padding: 10px;"><strong>Carrera</strong></td>
                                <td  style="padding: 10px;"><strong>Vinculada</strong></td>
                                <td  style="padding: 10px;"><strong>Estatus</strong></td>
                                <td  style="padding: 10px;"><strong>Validar</strong></td>
                               
                            </tr>
                        </thead>
                        <tbody><!--fetch_asoc es un arreglo asociativo-->
                            <?php
                            if ($buscar == true) {
                                ?>
                                <tr>
                                    <td>
                                        <form action="PropuestasEmp.php" method="post">
                                            <input type="radio" name="rm" value="<?php echo $id ?>">
                                            <button type="submit" value="elimina" name="btn" class="btn btn-danger">Eliminar</button>
                                        </form>
                                    </td>
                                    
                                    <td><?php echo $id ?></td>
                                    <td><?php echo $nomEm ?></td>
                                    <td><?php echo $imgEmp ?></td>
                                    <td><?php echo $tamaEmp ?></td>
                                    <td><?php echo $caractEmp ?></td>
                                    <td><?php echo $infoEmp ?></td>
                                    <td><?php echo $nomcr ?>,Area: <?php echo $carEmp ?></td>
                                     <td><?php echo $rfcEmp ?></td>
                                     
                                       <form action="PropuestasEmp.php" method="post">
                                                      <td>
                                                          <input type="hidden" name="empresaID" value="<?php echo $fila['id_emp']; ?>" >
                                <select  name="estatusVin" id=""  class="form-control" style="height: 60px;width: 180px;">
                                    <option value="Si">Si</option>
                                   
                                    <option value="No">No</option>
                                </select>
                            </td>
                                                   <td>
                                <select  name="estatusEmp" id=""  class="form-control" style="height: 60px;width: 180px;">
                                    <option value="Aprobada">Aprobada</option>
                                   
                                    <option value="Rechazada">Rechazada</option>
                                </select>
                                                                      
                            </td>
                            <td>
                                <button type="submit" name="btn" value="actualizar" class="btn btn-info">Enviar</button> 
                            </td>
                                                </form>
                                </tr>
                                <?php
                            } else {

                                $result = muestraProEmpresas($_SESSION['usuario_id']);
                                if ($result->num_rows > 0) {
                                    while ($fila = $result->fetch_assoc()) {
                                        ?>
                                        <tr>
                                            <td>
                                                <form action="PropuestasEmp.php" method="post">
                                                    <input type="radio" name="rm" value="<?php echo $fila['id_emp']; ?>">
                                                    
                                                     <button type="submit" value="elimina" name="btn" class="btn btn-danger">Eliminar</button>
                                                </form>
                                            </td>

                                            <td><?php echo $fila['id_emp']; ?></td>
                                            <td><?php echo $fila['nombre_e']; ?></td>
                                            <td><?php echo $fila['imagen_empresa']; ?></td>
                                            <td><?php echo $fila['Tamaño']; ?></td>
                                            <td><?php echo $fila['Caracteristicas']; ?></td>
                                            <td><?php echo $fila['Informacion']; ?></td>
                                            <td><?php echo $fila['RFC']; ?></td>
                                            <td><?php echo $fila['nombre_cr']; ?>,<br><?php echo $fila['Area']; ?></td>
                                            
                                         
                                            
                                       
                                                <form action="PropuestasEmp.php" method="post">
                                                      <td>
                                                          <input type="hidden" name="empresaID" value="<?php echo $fila['id_emp']; ?>" >
                                <select  name="estatusVin" id=""  class="form-control" style="height: 60px;width: 180px;">
                                    <option value="Si">Si</option>
                                   
                                    <option value="No">No</option>
                                </select>
                            </td>
                                                   <td>
                                <select  name="estatusEmp" id=""  class="form-control" style="height: 60px;width: 180px;">
                                    <option value="Aprobada">Aprobada</option>
                                   
                                    <option value="Rechazada">Rechazada</option>
                                </select>
                                                                      
                            </td>
                            <td>
                                <button type="submit" name="btn" value="actualizar" class="btn btn-info">Enviar</button> 
                            </td>
                                                </form>
                                           
                                        </tr>
                                        <?php
                                    }
                                }
                            }
                            ?>
                        </tbody>
                        </table></center>
                </div>
            </div>
    <!--            <script type="text/javascript">
                function Preguntar(idP){
                    if(confirm('Se eliminara el registro'+idP+'?'))
                    {
                    
                    window.location.href="./php_files/lib_empresas.php?id=" + idP;
                }
            </script>-->
        </section>


        <?php
    } else {
        header("Location: http://localhost/ProyectoEstadias/Login.php ");
    }
    ?>
    <!-- footer part end-->
    
    <!-- jquery plugins here-->
    <!-- jquery -->
    <script src="js/jquery-1.12.1.min.js"></script>
    <script src="js/ajax-jquery.min.js.js"></script>
    <!-- popper js -->
    <script src="js/popper.min.js"></script>
    <!-- bootstrap js -->
    <script src="js/bootstrap.min.js"></script>
    <!-- particles js -->
    <script src="js/contact.js"></script>
    <!-- ajaxchimp js -->
    <script src="js/jquery.ajaxchimp.min.js"></script>
    <!-- validate js -->
    <script src="js/jquery.validate.min.js"></script>
    <!-- form js -->
    <script src="js/jquery.form.js"></script>
    <script src="js/mail-script.js"></script>
    <!-- custom js -->
    <script src="js/custom.js"></script>
</body>

</html>
