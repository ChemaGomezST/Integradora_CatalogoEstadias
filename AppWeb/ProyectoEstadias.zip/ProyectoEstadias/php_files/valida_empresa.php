<?php

require_once 'Conecta.php';
$foto=$_FILES["foto"]["name"];
$ruta=$_FILES["foto"]["tmp_name"];
$destino="../fotos/".$foto;
copy($ruta,$destino);
$nombreE=$_REQUEST['nomE'];
$tamaño=$_REQUEST['CbotamañoE'];
$caracteristicas=$_REQUEST['caract'];
$informacion=$_REQUEST['info'];
$vinculada=$_REQUEST['cboVin'];
$RFC=$_REQUEST['rfc'];
$total_vacantes=$_REQUEST['totalV'];
$ubicacion=$_REQUEST['cbx_ubicacion'];
$sql = "insert into empresas (imagen_empresa,Nombre,Tamaño,Caracteristicas,Informacion,Vinculada,RFC,total_vacantes,ubicaciones_id)  values('".$destino."','".$nombreE."','".$tamaño."','".$caracteristicas."','".$informacion."','".$vinculada."','".$RFC."',".$total_vacantes.",".$ubicacion.");";
$con = Conectar();
$con->query($sql);
$con->close();
    echo "<script type='text/javascript'>alert('Datos guardados en la BD');</script>";
//header("Location: Registro_Empresas.php");
?>

