<?php
include './Conecta.php';
$imgEmpresa="fotos/IMSS.jpg";
$nombre_e=$_POST['nombreEmp'];
$tamañoEmp=$_POST['tamañoEmp'];
$caractEmp=$_POST['caractEmp'];
$infoEmp=$_POST['infoEmp'];
$vinculaEmp="No";
$rfcEmp=$_POST['rfcEmp'];
$total_vacantesEmpresa="Tenemos Vacantes";
$estatusEmpresa="En Proceso";
$carrera_id=2;
$dirEmp=$_POST['dirEmp'];

//
//
//$imgEmpresa="fotos/IMSS.jpg";
//$nombre_e="nombre_e";
//$tamañoEmp="Mediana";
//$caractEmp="Muy grande";
//$infoEmp="Nececitamos Esclavos";
//$vinculaEmp="No";
//$rfcEmp="MLDASDAS";
//$total_vacantesEmpresa="Tenemos Vacantes";
//$estatusEmpresa="En Proceso";
//$direccion="Ofelia Galindo";
//$carrera_id=2;




    $sql = "INSERT INTO empresas (imagen_empresa,nombre_e,Tamaño,Caracteristicas,Informacion,Vinculada,RFC,total_vacantes,estatus,carreras_id,fecha_upload,ubicacion) values('".$imgEmpresa."','".$nombre_e."','".$tamañoEmp."','".$caractEmp."','".$infoEmp."','".$vinculaEmp."','".$rfcEmp."','".$total_vacantesEmpresa."','".$estatusEmpresa."',".$carrera_id.",NOW(),'".$dirEmp."');";
    $con= Conectar();
    $con->query($sql);
    $con->close();
    echo $sql;
    ?>