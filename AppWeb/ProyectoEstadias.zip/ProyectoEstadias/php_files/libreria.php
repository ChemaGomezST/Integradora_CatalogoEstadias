<?php
include 'Conecta.php';
function GuardarUsuario($correo ,$contraseña ,$estatus,$tipo_usuario){
    $sql="insert into usuarios (correo,contraseña,estatus,tipo_usuario)  values ('".$correo."','".$contraseña."','".$estatus."','".$tipo_usuario."');";
    $con= Conectar();
    $con->query($sql);
    $con->close();
    echo "<script type='text/javascript'>alert('Datos guardados en la BD');</script>";
    
    
}

function seleccion(){
    $sql="select * from usuarios";
    $con= Conectar();
    $result = $con->query($sql);
    $con->close();
    return $result;
}
function buscar($correo){
    $sql="select * from usuarios where correo='".$correo."';";
    $con=  Conectar();
    $result= $con->query($sql);
    $con->close();
    return $result;    
    
}
function eliminar($correo){
    $sql="Delete from usuarios where correo='".$correo."';";
    
    $con=  Conectar();
    $result= $con->query($sql);
    return $result;       
}
function modificar($correo ,$contraseña ,$estatus,$tipo_usuario){
    $sql="update usuarios set contraseña='".$contraseña."',estatus='".$estatus."',tipo_usuario='".$tipo_usuario."' where correo='".$correo."';";
    $con=  Conectar();
    $result= $con->query($sql);
    $con->close();
    return $result;
}
function valida_usuario($correo,$contraseña){
    $sql="select * from usuarios where correo='".$correo."' and contraseña='".$contraseña."'";
    $con=  Conectar();
    $result= $con->query($sql);
    return $result;
}

//function muestraEmpresa(){
//      $sql="select * from empresas";
//    $con=  Conectar();
//    $result= $con->query($sql);
//    return $result;
//    
//}

 
?>
