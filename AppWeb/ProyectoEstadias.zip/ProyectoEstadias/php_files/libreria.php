<?php
include 'Conecta.php';
function GuardarUsuario($correo ,$contraseña ,$estatus,$tipo_usuario){
    $sql="insert into usuarios (correo,contraseña,estatus,tipo_usuario)  values ('".$correo."','".$contraseña."','".$estatus."','".$tipo_usuario."');";
    $con= Conectar();
    $con->query($sql);
    $con->close();
    echo "<script type='text/javascript'>alert('Datos guardados en la BD');</script>";
    echo $sql;
    
}

function seleccion(){
    $sql="select * from usuarios order by id desc;";
    $con= Conectar();
    $result = $con->query($sql);
    $con->close();
    return $result;
}
function seleccionUser($idUs){
    $sql="SELECT * FROM usuarios where id='".$idUs."';";
    $con= Conectar();
    $result = $con->query($sql);
    $con->close();
    return $result;
}
function buscar($correo){
    $sql="select * from usuarios where correo='".$correo."';";
    $con=  Conectar();
    $result= $con->query($sql);
    $con->close();
    return $result;    
    
}
function eliminar($correo){
    $sql="Delete from usuarios where correo='".$correo."';";
    
    $con=  Conectar();
    $result= $con->query($sql);
    return $result;       
}
function modificar($correo ,$contraseña ,$estatus,$tipo_usuario){
    $sql="update usuarios set contraseña='".$contraseña."',estatus='".$estatus."',tipo_usuario='".$tipo_usuario."' where correo='".$correo."';";
    $con=  Conectar();
    $result= $con->query($sql);
    $con->close();
    return $result;
}
function registraAlumno($matricula,$numSeguro,$nombreA,$carrera_id,$usuario_id){
    $sql="INSERT INTO alumnos (matricula,num_seguro,nombre_completo,carreras_id,usuarios_id) VALUES ('".$matricula."','".$numSeguro."','".$nombreA."',".$carrera_id.",".$usuario_id.");";
    $con= Conectar();
    $con->query($sql);
    $con->close();
    echo "<script type='text/javascript'>alert('Alumno Registrado');</script>";
    
    
}
function registraPersonal($matriculaT,$nombreT,$departamento,$carrera_id,$usuario_id){
    $sql="INSERT INTO personal (matricula_trabajador,nombre_completo,departamento,carreras_id,usuarios_id) VALUES "
            . "('".$matriculaT."','".$nombreT."','".$departamento."',".$carrera_id.",".$usuario_id.");";
    $con= Conectar();
    $con->query($sql);
    $con->close();
    echo "<script type='text/javascript'>alert('Datos guardados en la BD');</script>";
    
    
}
function valida_usuario($correo,$contraseña){
    $sql="select * from usuarios where correo='".$correo."' and contraseña='".$contraseña."'";
    $con=  Conectar();
    $result= $con->query($sql);
    return $result;
}
function ($idUser){
    $sql="SELECT a.matricula,a.num_seguro,a.nombre_completo FROM usuarios u
join alumnos a on a.usuarios_id=u.id where u.id='".$idUser."';";
    $con= Conectar();
    $result = $con->query($sql);
    $con->close();
    return $result;

}
//function muestraEmpresa(){
//      $sql="select * from empresas";
//    $con=  Conectar();
//    $result= $con->query($sql);
//    return $result;
//    
//}

 
?>
