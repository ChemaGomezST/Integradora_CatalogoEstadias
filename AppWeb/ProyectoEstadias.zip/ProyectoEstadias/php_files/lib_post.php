<?php
include 'Conecta.php';
function InsertaPostulación($destino,$empresa_id,$usuario_id){
    $sql = "INSERT INTO postulaciones (Fecha_postulacion, curriculum_v,empresas_id,usuarios_id)  values(NOW(),'".$destino."',".$empresa_id.",".$usuario_id.");";
    $con= Conectar();
    $con->query($sql);
    $con->close();
    echo "<script type='text/javascript'>alert('Datos guardados en la BD');</script>";
         
}
function muestraPostulacion(){
    $sql="SELECT p.id,e.id_emp,a.nombre_completo,a.matricula,c.nombre_cr,c.Area,e.nombre_e,p.Fecha_postulacion,p.curriculum_v FROM postulaciones p
join empresas e on e.id_emp=p.empresas_id
join usuarios u on u.id=p.usuarios_id
join carreras c on c.id=e.carreras_id
join alumnos a on a.carreras_id=c.id
order by p.id DESC
;";
    $con= Conectar();
    $result = $con->query($sql);
    $con->close();
    return $result;
}
function buscar($id,$empresas_id){
    $sql="SELECT p.id,e.id_emp,a.nombre_completo,a.matricula,c.nombre_cr,c.Area,e.nombre_e,p.Fecha_postulacion,p.curriculum_v FROM postulaciones p
join empresas e on e.id_emp=p.empresas_id
join usuarios u on u.id=p.usuarios_id
join carreras c on c.id=e.carreras_id
join alumnos a on a.carreras_id=c.id where p.id=".$id." or e.id_emp=".$empresas_id.";";
    $con=  Conectar();
    $result= $con->query($sql);
    $con->close();
    return $result;    
    
}
function eliminarPostulacion($id){
    $sql="Delete from postulaciones where id=".$id.";";
    $con=  Conectar();
    $result= $con->query($sql);
    return $result;       
}

?>