<?php
include 'Conecta.php';
function InsertaPostulación($destino,$empresa_id,$usuario_id){
    $sql = "INSERT INTO postulaciones (Fecha_postulacion, curriculum_v,empresas_id,usuarios_id)  values(NOW(),'".$destino."',".$empresa_id.",".$usuario_id.");";
    $con= Conectar();
    $con->query($sql);
    $con->close();
    echo "<script type='text/javascript'>alert('Postulación Guardada');</script>";
         
}
function guardaAceptación($destino2,$id_usuario){
        $sql="UPDATE postulaciones SET cartaAceptacion='".$destino2."' WHERE usuarios_id='".$id_usuario."'";
    $con= Conectar();
    $result = $con->query($sql);
    $con->close();
    return $result;
    
}
function muestraPostulacion($idP){
    $sql="select distinct po.id,a.nombre_completo,a.matricula,c.nombre_cr,c.Area,e.nombre_e,po.Fecha_postulacion,po.curriculum_v,po.estatusPost,po.cartaAceptacion,po.cartaAceptacion from postulaciones po
join empresas e on po.empresas_id=e.id_emp
join carreras c on c.id=e.carreras_id
join personal pe on c.id=pe.carreras_id
join alumnos a on c.id=a.carreras_id
join usuarios u on pe.usuarios_id=u.id where u.id='".$idP."' and po.usuarios_id=a.usuarios_id order by id desc;";
    $con= Conectar();
    $result = $con->query($sql);
    $con->close();
    return $result;
}
function buscar($id,$empresas_id){
    $sql="SELECT p.id,e.id_emp,a.nombre_completo,a.matricula,c.nombre_cr,c.Area,e.nombre_e,p.Fecha_postulacion,p.curriculum_v,p.estatusPost,p.cartaAceptacion FROM postulaciones p
join empresas e on e.id_emp=p.empresas_id
join usuarios u on u.id=p.usuarios_id
join carreras c on c.id=e.carreras_id
join alumnos a on a.carreras_id=c.id where p.id=".$id." or e.id_emp=".$empresas_id.";";
    $con=  Conectar();
    $result= $con->query($sql);
    $con->close();
    return $result;    
    
}
function eliminarPostulacion($id){
    $sql="Delete from postulaciones where id=".$id.";";
    $con=  Conectar();
    $result= $con->query($sql);
    return $result;       
}

//function muestraPost($idUser){
//    
//    $sql="SELECT * FROM postulaciones where usuarios_id=".$idUser." ;";
//    $con=  Conectar();
//    $result= $con->query($sql);
//    $con->close();
//    echo $sql;
//    return $result;
//    
//    
//   
//    
//}


?>