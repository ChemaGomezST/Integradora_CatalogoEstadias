<?php
include_once  'Conecta.php';
/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
function ingresaEmpresa($destino,$nombreE,$tamaño,$caracteristicas,$informacion,$vinculada,$RFC,$total_vacantes,$estatusEmp,$carrera_id,$ubicacion){
    $sql = "INSERT INTO empresas (imagen_empresa,nombre_e,Tamaño,Caracteristicas,Informacion,Vinculada,RFC, total_vacantes,estatus,carreras_id,fecha_upload,ubicacion) values('".$destino."','".$nombreE."','".$tamaño."','".$caracteristicas."','".$informacion."','".$vinculada."','".$RFC."','".$total_vacantes."','".$estatusEmp."',".$carrera_id.",NOW(),'".$ubicacion."');";
    $con= Conectar();
    $con->query($sql);
    $con->close();

   
    
    
       
}
function GuardarProEmpresa($nombreEmp ,$contacto ,$totalVac,$usuarioId,$procesoId){
    $sql="insert into propuesta (Nombre_empresa,Contacto,Total_vacantes,usuarios_id,Procesos_id)  values ('".$nombreEmp."','".$contacto."','".$totalVac."',".$usuarioId.",".$procesoId.");";
    $con= Conectar();
    $con->query($sql);
    $con->close();
    echo "<script type='text/javascript'>alert('Empresa Registrada');</script>";
    
    
}

function muestraProEmpresas($idUserP){
    $sql="SELECT e.id_emp,e.nombre_e,e.imagen_empresa,e.Tamaño,e.Caracteristicas,e.Informacion,e.Vinculada,e.RFC,e.total_vacantes,e.estatus,c.nombre_cr,c.Area FROM empresas e
join carreras c on c.id=e.carreras_id
join personal p on p.carreras_id=c.id
join usuarios u on p.usuarios_id=u.id
where u.id='".$idUserP."' order by e.id_emp desc;";
    $con=  Conectar();
    $result= $con->query($sql);
    return $result;    
}
function eliminarEmp($idEmp){
    $sql="delete from empresas where id_emp='".$idEmp."'";
    $con=  Conectar();
    $result= $con->query($sql);
    return $result;    
    echo $sql;
}
function buscarProEmp($idProEmp){
    $sql="SELECT e.id_emp,e.nombre_e,e.imagen_empresa,e.Tamaño,e.Caracteristicas,e.Informacion,e.Vinculada,e.RFC,e.total_vacantes,e.estatus,c.nombre_cr,c.Area FROM empresas e
join carreras c on c.id=e.carreras_id
join personal p on p.carreras_id=c.id
join usuarios u on p.usuarios_id=u.id where e.id_emp=".$idProEmp.";";
    $con=  Conectar();
    $result= $con->query($sql);
    return $result;    
}

function seleccionaEmpresa($idEmp){
    
     $sql="select * from empresas e join
carreras c on c.id=e.carreras_id
where e.id_emp={$idEmp}";
    $con=  Conectar();
    $result= $con->query($sql);
    return $result;    
}



function ingresaComentario($calificacion,$coment,$empresaID,$usuarioID)
{
    $sql = "INSERT INTO evaluacion_estadia (Calificacion,Comentarios,empresas_id,usuarios_id,fecha_coment) VALUES ('".$calificacion."','".$coment."',".$empresaID.",".$usuarioID.",NOW());";
    $con= Conectar();
    $con->query($sql);
    $con->close();
    echo $sql;
   
    
    
}
function  muestraComentariosEmpresa($idEmpC){
         $sql="SELECT a.nombre_completo,ev.Comentarios,ev.Calificacion,ev.fecha_coment
 FROM   evaluacion_estadia ev
join empresas e on ev.empresas_id=e.id_emp
join usuarios u on ev.usuarios_id=u.id
join alumnos a on a.usuarios_id=u.id where e.id_emp=$idEmpC
;";
    $con=  Conectar();
    $result= $con->query($sql);
    return $result;    
    
}

function muestraAllEmpresas($idPe){
    $sql="SELECT  e.fecha_upload,c.nombre_cr,c.Area,e.imagen_empresa,u.tipo_usuario,e.nombre_e,e.Informacion,e.Caracteristicas,e.id_emp,e.ubicacion FROM usuarios u 
                            join personal p on p.usuarios_id=u.id
                            join carreras c on p.carreras_id=c.id
                            join empresas e on e.carreras_id=c.id
                            where u.id='".$idPe."' and e.estatus='Aprobada' order by e.id_emp desc limit 12  ;";
   $con=  Conectar();
    $result= $con->query($sql);
    return $result;    
    
}
function muestraEmpresasCarrera($idUser){
    $sql="SELECT  e.fecha_upload,c.nombre_cr,c.Area,a.nombre_completo,e.imagen_empresa,u.tipo_usuario,e.nombre_e,e.Informacion,e.Caracteristicas,e.id_emp,e.ubicacion FROM usuarios u 
                            join alumnos a on a.usuarios_id=u.id
                            join carreras c on a.carreras_id=c.id
                            join empresas e on e.carreras_id=c.id
                            where u.id= '".$idUser."' order by e.id_emp desc limit 12;";
                                 $con= Conectar();
                              $result= $con->query($sql);    
                              return $result;
}

function ActualizaEstatus($vincEm,$estatusEmp,$idEmp){
                
    $sql="UPDATE empresas SET Vinculada='".$vincEm."',estatus='".$estatusEmp."' WHERE id_emp='".$idEmp."'";
    $con= Conectar();
    $result = $con->query($sql);
    $con->close();
    return $result;
    
}
?>


