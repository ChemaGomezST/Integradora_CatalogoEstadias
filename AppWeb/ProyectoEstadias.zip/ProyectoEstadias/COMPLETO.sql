CREATE DATABASE  IF NOT EXISTS `bd_estadia` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `bd_estadia`;
-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: localhost    Database: bd_estadia
-- ------------------------------------------------------
-- Server version	5.7.19-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `alumnos`
--

DROP TABLE IF EXISTS `alumnos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `alumnos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `matricula` int(11) NOT NULL,
  `num_seguro` varchar(45) NOT NULL,
  `nombre_completo` varchar(60) NOT NULL,
  `carreras_id` int(11) NOT NULL,
  `usuarios_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_alumnos_carreras1_idx` (`carreras_id`),
  KEY `fk_alumnos_usuarios1_idx1` (`usuarios_id`),
  CONSTRAINT `fk_alumnos_carreras1` FOREIGN KEY (`carreras_id`) REFERENCES `carreras` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_alumnos_usuarios1` FOREIGN KEY (`usuarios_id`) REFERENCES `usuarios` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `alumnos`
--

LOCK TABLES `alumnos` WRITE;
/*!40000 ALTER TABLE `alumnos` DISABLE KEYS */;
INSERT INTO `alumnos` VALUES (7,160199,'IMMMS090909','Jose Maria Gomez Santos',2,98),(8,123456,'IMMS78909767','Israel Gomez Santamaria',2,100),(10,666666,'IMSASADASAS','PruebasCrazys',3,0),(11,160448,'IMMMSSASADAS','Alicia Ortega',1,90),(14,160199,'IMMDSDASA121','IMSDASDAA!\"2123',2,98),(15,160120,'IMMS31222DAS','America Gómez Santos',2,91),(16,1321213,'IMMMadsas','Luis Enrique Jimnez Gonzalez',3,83),(17,1321213,'IMMS31222DAS','Auerelio Gonzalez Martinez',3,101);
/*!40000 ALTER TABLE `alumnos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `carreras`
--

DROP TABLE IF EXISTS `carreras`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `carreras` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre_cr` varchar(50) NOT NULL,
  `Nivel` varchar(40) NOT NULL,
  `Director` varchar(90) NOT NULL,
  `Area` varchar(80) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `carreras`
--

LOCK TABLES `carreras` WRITE;
/*!40000 ALTER TABLE `carreras` DISABLE KEYS */;
INSERT INTO `carreras` VALUES (1,'Tecnologias de la información y Comunicacion','TSU','Jose Maria Gomez Santos','Sistemas Informaticos'),(2,'Tecnologias de la Informacion y Comunicación','ING','Esmeralda Hernandez Hernandez','Tecnoligias de la Información'),(3,'Administracion','TSU','Miguel Angel Leon Baños','Recursos Humanos');
/*!40000 ALTER TABLE `carreras` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contacto_empresa`
--

DROP TABLE IF EXISTS `contacto_empresa`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contacto_empresa` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Correo` varchar(45) NOT NULL,
  `Direccion` varchar(45) NOT NULL,
  `Encargado` varchar(45) NOT NULL,
  `empresas_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_contacto_empresa_empresas1_idx` (`empresas_id`),
  CONSTRAINT `fk_contacto_empresa_empresas1` FOREIGN KEY (`empresas_id`) REFERENCES `empresas` (`id_emp`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contacto_empresa`
--

LOCK TABLES `contacto_empresa` WRITE;
/*!40000 ALTER TABLE `contacto_empresa` DISABLE KEYS */;
/*!40000 ALTER TABLE `contacto_empresa` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `empresas`
--

DROP TABLE IF EXISTS `empresas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `empresas` (
  `id_emp` int(11) NOT NULL AUTO_INCREMENT,
  `imagen_empresa` varchar(1000) NOT NULL,
  `nombre_e` varchar(890) NOT NULL,
  `Tamaño` enum('Pequeña','Mediana','Grande') NOT NULL,
  `Caracteristicas` varchar(5000) NOT NULL,
  `Informacion` varchar(5000) NOT NULL,
  `Vinculada` enum('En Proceso','Si','No') NOT NULL,
  `RFC` varchar(450) NOT NULL,
  `total_vacantes` varchar(200) NOT NULL,
  `estatus` enum('En Proceso','Aprobada','Rechazada') NOT NULL,
  `carreras_id` int(11) NOT NULL,
  `fecha_upload` datetime DEFAULT NULL,
  `ubicacion` varchar(850) NOT NULL,
  PRIMARY KEY (`id_emp`),
  KEY `fk_empresas_carreras1_idx` (`carreras_id`),
  CONSTRAINT `fk_empresas_carreras1` FOREIGN KEY (`carreras_id`) REFERENCES `carreras` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=154 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `empresas`
--

LOCK TABLES `empresas` WRITE;
/*!40000 ALTER TABLE `empresas` DISABLE KEYS */;
INSERT INTO `empresas` VALUES (42,'fotos/450_1000.jpg','Wolskvagen','Grande','Para los jÃ³venes interesados en participar, los requisitos son:','La convocatoria estÃ¡ abierta a estudiantes de carreras relacionadas con las Ã¡reas de:','Si','UTXJ2004HPLMNE33','12','Rechazada',2,'2019-07-31 03:47:49',' Periferico Sur 4121, Fuentes del Pedregal, 14141 Tlalpan, CDMX'),(43,'fotos/IMSS.jpg','IMMS','Pequeña','ReparciÃ³n de relojes de pulso,analogicos y construcciÃ³n de relojes solares','Requerimos de personal capacitado en el area de administración ','No','RLJMN01010101','2','Rechazada',2,'2019-07-31 03:47:49','Xicotepec de Juarez Puebla,Mexico'),(44,'fotos/azteca.jpg','Tv Azteca','Pequeña','Requisitos:','PRACTICANTES DE EDICIÃ“N DIGITAL - TV AZTECA','Si','123467','12','En Proceso',2,'2019-07-31 03:47:49',' Periferico Sur 4121, Fuentes del Pedregal, 14141 Tlalpan, CDMX'),(45,'fotos/bimbo.jpeg','Bimbo','Pequeña','Â¿QuÃ© buscamos?','Programa de prÃ¡cticas','Si','123467','12','En Proceso',2,'2019-07-31 03:47:49','Corporativo Bimbo S.A. de C.V.'),(46,'fotos/coca.jpeg','Coca Cola','Pequeña','No se atenderÃ¡n solicitudes enviadas en formato OCC','Auxiliar servicio a ventas','Si','123467','12','En Proceso',2,'2019-07-31 03:47:49','Puebla, Puebla'),(47,'fotos/manto.jpg','2122','Mediana','11111113','sddddddddd12321','Si','Universidad Tecnológica de Xicotepec de Juarez','123','En Proceso',2,'2019-07-31 03:47:49','Huachinango Puebla,Mexico'),(48,'fotos/travelent.jpg','Travelnet','Pequeña','EXPERIENCIA','ANALISTA DE SISTEMAS INFORMÃTICOS','Si','Universidad Tecnológica de Xicotepec de Juarez','223','En Proceso',2,'2019-07-31 03:47:49','RÃ­o Ganges 45, CuauhtÃ©moc, 06500 Ciudad de MÃ©xico, CDMX'),(49,'fotos/1 (1).jpg','wdqwq','Pequeña','aaaasdasda','123123adad','Si','Universidad Tecnológica de Xicotepec de Juarez','223','En Proceso',2,'2019-07-31 03:47:49',''),(50,'fotos/televisa.jpg','Televisa','Pequeña','REQUISITOS:','Lugar de Trabajo:','Si','qwertyu12345','12','En Proceso',2,'2019-07-31 03:47:49','CoyoacÃ¡n, Distrito Federal'),(51,'fotos/asosa.jpg','Asosa','Pequeña','CaracterÃ­sticas:','Especialista en infraestructura TI','Si','qwertyu12345','12','En Proceso',2,'2019-07-31 03:47:49','Azcapotzalco'),(52,'fotos/1.jpg','qwerty2','Pequeña','qqetewe12','qweerer','Si','qwertyu12345','12','En Proceso',2,'2019-07-31 03:47:49',''),(53,'fotos/1 (1).jpg','TeamDevelopment12','Pequeña','qwerty2','qwett123','Si','Universidad Tecnológica de Xicotepec de Juarez','222','En Proceso',2,'2019-07-31 03:47:49',''),(54,'fotos/manto.jpg','Grupo Modelo','Mediana','','TeamDevelopment123','Si','TeamDevelopment123','12','En Proceso',2,'2019-07-31 03:47:49','Xicotepec de Juarez Puebla,Mexico'),(55,'fotos/compucentro.jpg','Compucentro','Mediana','Requisitos indispensables:','TÃ©cnico de ImplementaciÃ³n POR PROYECTO','Si','TeamDevelopment123','12','En Proceso',2,'2019-07-31 03:47:49','Edo de Mex. (norte)'),(56,'fotos/iapza.jpg','Iapza','Mediana','LÃDER DE PROYECTO','LÃDER DE PROYECTO','Si','TeamDevelopment123','12','En Proceso',2,'2019-07-31 03:47:49','Calle Yacatas 465, Narvarte Poniente, 03000 Benito Juarez, CDMX'),(57,'fotos/iconinnova.jpg','Innova','Mediana','          Ofrecemos:','PROJECT MANAGER','Si','TeamDevelopment123','12','En Proceso',2,'2019-07-31 03:47:49','CDMX: AlcaldÃ­a Benito JuÃ¡rez (Cerca del metro Mixcoac).'),(58,'fotos/IZZI.jpg','IZZI','Mediana','FUNCIONES DEL PUESTO:','EJECUTIVO SERVICIO A CLIENTES EMPRESARIAL','Si','TeamDevelopment123','12','En Proceso',2,'2019-07-31 03:47:49','Estado de MÃ©xico, sucursal los Reyes â€“ Av. Puebla NÂ° .81 Col. Los Reyes Acaquilpan C.P. 56400'),(71,'fotos/82.jpeg','Utxj','Mediana','asdsadasdas','asdasdas','Si','Universidad Tecnológica de Xicotepec de Juarez','123','En Proceso',3,'2019-07-31 03:47:49',''),(72,'fotos/82.jpeg','TeamDevelopment12321321','Mediana','adasdsadasdasda','dsadasdasdasasda','Si','dsadasdasdadadqewe','12','En Proceso',3,'2019-07-31 03:47:49',''),(73,'fotos/483.jpg','Prueba','Pequeña','Prueba','Prueba','Si','123467','123','En Proceso',3,'2019-07-31 03:47:49',''),(74,'fotos/483.jpg','Prueba','Pequeña','Prueba','Prueba','Si','123467','123','En Proceso',3,'2019-07-31 03:47:49',''),(75,'fotos/483.jpg','adsdasdasdasda','Pequeña','fgfhsff','fgffdfsgh','Si','gsgfdfs','22','En Proceso',3,'2019-07-31 03:47:49',''),(105,'fotos/4202.jpg','Empresa de Lisha','Mediana','Es de lisha','Por Lisha','Si','LISHARMLAKAS','111','En Proceso',1,'2019-08-03 17:34:06',''),(130,'fotos/11.jpg','Copachisa','Grande','Para ésta última compartió su programa que contempla acciones que incentiven la colaboración y fortalezcan el sentido de pertenencia, mejorando la gestión del conocimiento, la comunicación, la colaboración, la creación de estrategias, así como el rendimiento de los empleados, beneficiando los resultados del área.','Copachisa, contratista general de diseño y construcción mexicano con proyección internacional que inició en 1958 bajo el nombre de Terrazas y Valdéz en Chihuahua,','Si',' P8002013X6','Requerimos de Pasantes','Aprobada',3,'2019-08-21 00:42:47','Chihuahua, Chihuahua, México'),(131,'fotos/Gallery-QR-QRPUE-43201840758PM.jpg','Hotel Quinta Real Puebla ','Mediana','Estamos en búsqueda de talento humano comprometido con la hospitalidad y el servicio personalizado e interesados en formar parte de un equipo de profesionales innovadores y lideres en la hotelería mexicana\r\n\r\nRequerimientos:\r\nEscolaridad Licenciatura en Administración de Empresas Turísticas o fin\r\nExperiencia mínima de 6 meses (deseable; pueden ser practicas profesiones)\r\nExcelente presentación\r\nFacilidad de Palabra\r\nAtención al Cliente\r\nExcelente actitud de servicio','Este hotel exclusivo ubicado en un antiguo convento del siglo XVI se encuentra a 4 minutos a pie de las obras de arte del Museo Amparo y a 5 minutos a pie de la catedral de Puebla, del siglo XVI.\r\n','Si','HTRALWGHHGF87','Requerimos de Pasantes','Aprobada',3,'2019-08-21 01:10:13','Av 7 Pte 105, Centro, 72000 Puebla, Pue.'),(132,'fotos/5.png','Giga IT S.C.V','Mediana','En esta oportunidad requerimos estudiantes o egresados con especialidad en Psicología, Administración o carreras afines interesados en realizar prácticas profesionales o servicio social, con iniciativa y ganas...','Grupo GIGA es una empresa líder integradora de tecnologías y soluciones que apunta a brindar sus servicios en el área de Automatización IT. Para ello contamos con un equipo con vasta experiencia en cada área, que se compromete para lograr el éxito de cada proyecto, consolidándonos como una de las empresas de software y automatización más influyentes en México, Estados Unidos y Latinoamérica.','Si','GIG90009DPAG21','Requerimos de Pasantes','Aprobada',3,'2019-08-21 02:11:24','San Nicolas de los Garza Veracruz'),(133,'fotos/4.jpeg','DICOISA','Grande','Se libera Servicio Social, Prácticas Profesionales o si quieres adquirir Experiencia Profesional PASANTES O TITULADOS.\r\nCarreras Lic. Psicología, Lic. en Administración de Empresas, Lic. en Contabilidad.\r\nRequerimientos\r\nEducación mínima: Educación superior - Licenciatura\r\nIdiomas: Inglés\r\nEdad: entre 23 y 26 años\r\nDisponibilidad de viajar: No\r\nDisponibilidad de cambio de residencia: No\r\n','Estamos ubicados en Av. San Francisco 12, Col. San Francisco Cuautlalpan, Naucalpan de Juárez, Edo. de México. C.P. 53569.\r\nOfrecemos apoyo económico 3,120 pesos mensuales y comedor gratuito.\r\nHorarios lunes a viernes de 8am a 5pm con una hora de comida.','Si','TIE830322QV7','Requerimos de Pasantes','Aprobada',3,'2019-08-21 02:33:52','San Francisco 12, San Jose de los Leones Primera Secc, 53569 Naucalpan de Juárez, Méx.'),(134,'fotos/descarga.jpg','Máquinas Información y Tecnología Avanzada S.A. de C.V.','Grande','Importante empresa líder en el ramo de fotocopiado te invita a liberar tu Servicio Social ó Practicas Profesionales\r\nLic. Administración\r\nREQUISITOS\r\nSexo Indistinto\r\nEscolaridad haber concluido mínimo el 6 Semestres \r\nFUNCIONES\r\nAnálisis de los servicios diarios','egún nuestros datos, Máquinas Información y Tecnología Avanzada S.A. de C.V. publicó 154 ofertas en los últimos 12 meses y en estos momentos tiene 10 ofertas activas en JobisJob. Las 2 principales categorías donde Máquinas Información y Tecnología Avanzada S.A. de C.V. publica sus ofertas son Ingeniería con 28.6% y IT - Sistemas - Tecnología con 24.7% del total de sus ofertas.','Si','T841126LL8','Requerimos de Pasantes','Aprobada',3,'2019-08-21 02:38:28','Cto. Interior Melchor Ocampo 193, Verónica Anzúres, 11300 Ciudad de México, CDMX'),(135,'fotos/3.jpg','Servicio Central S. A. de C.V.  ','Grande','Solicita Becario de RH para liberación de practicas profesionales o servicio social.\r\nSi te encuentras en los últimos semestres de carreras técnicas o licenciaturas como Psicología, Administración, Pedagogía o afín, y requieres liberar tus practicas profesionales, y obtener experiencia en tu área, postulate con nosotros.\r\nOfrecemos\r\nayuda económica de 350.00 semanales.\r\nAprendizaje sobre diferentes tareas de R.H.\r\nHorario a elegir. 4 horas diarias por las mañanas.\r\nDuración del Proyecto, el señalado por la institución educativa.','Servicio Central pertenece a Grupo Bavaria, somos un distribuidor autorizado de la marca de Autos BMW, somos los lideres en ventas de autos premium a nivel nacional. Comercializamos con la marca BMW, ofrecemos autos tanto de la marca BMW, MINI Y ROLLS ROICE.','Si','SVRCSSA213','Requerimos de Pasantes','Aprobada',3,'2019-08-21 02:45:43','Schiller 248, Polanco, Polanco V Secc, 11570 Ciudad de México, CDMX'),(136,'fotos/8.jpg','EXCEL  ','Mediana','Solicito AUXILIAR DE FACTURACIÓN \r\nHORARIO De Lunes a Viernes.\r\nVacante para cubrir Incapacidad por Maternidad\r\nEscolaridad Recien egresado, Licenciatura en Contabilidad o Administración Concluida, Titulado o Pasante o ultimo semestre.','Únete a nuestro equipo como Auxiliar de Facturación en crecimiento para brindar asistencia a Clientes de México, porque, Ofreciendo un excelente Servicio y Atención a nuestros Clientes Buenas oportunidades de desarrollo dentro de nuestra empresa EXCEL CONSULTORES con mas de 20 años en el mercado','Si','EXRWRLLE21','Requerimos de Pasantes','Aprobada',3,'2019-08-21 02:51:29','Avenida Prado Norte 305, Lomas - Virreyes, Lomas de Chapultepec, 11000 Ciudad de México, CDMX'),(137,'fotos/6.jpg','Habers','Grande','Requisitos:\r\n*ser estudiante de los últimos semestres en Administración o Admin. de Empresas.\r\n*edad: 21 a 30 años\r\nSexo:Indistinto\r\nContar con seguro facultativo\r\nDisponibilidad de asistir 4hrs diarias\r\nActividades:\r\ncaptura de Información, descargas de archivos y validación de información en el sistema.','Busca estudiantes que quieran realizar sus PRACTICAS PROFESIONALES O SERVICIO SOCIAL en el área ADMINISTRATIVA.\r\nOfrecemos:\r\nExperiencia dentro del área\r\nLiberación del servicio o practicas profesionales\r\nAyuda de transporte de $300.00 semanales\r\nLugar de Estadía: Forum Naucalpan\r\nInteresados postularse por este medio','Si','RFC: A820119CW0','Requerimos de Pasantes','Aprobada',3,'2019-08-21 03:13:50','Naucalpan de Juárez, Méx.'),(138,'fotos/descarga (1).jpg','Tecnoregistro S.A. de CV','','Actividades a Desarrollar:\r\n- Apoyar en los procesos generales de RRHH sobre el giro de negocio.\r\n- Apoyar en la ejecución del Plan Anual de Capacitación\r\n- Apoyar en la ejecución del Plan Anual de Comunicación Interna\r\nHabilidades:\r\n- Proactivo(a)\r\n- Crear buenas relaciones con clientes,proveedores y colaboradores internos\r\n- Innovación\r\n- Responsable\r\n- Comunicación\r\nApoyo económico de $ 3,000 MXN Mensuales\r\nLunes a Viernes Horario: 9:00 - 3:00 pm','Somos T&C Group, una empresa dedicada al giro de Organización de eventos y Turismo de Negocios, con mas de 29 años en el mercado.\r\nEstamos en búsqueda de un pasante o becario para el área de Recursos Humanos.\r\nFormación Académica: Pasantes, estudiantes del último año en las siguientes carreras: Psicología, Administración de Empresas, Comunicación.','Si','TEC991029F92','Requerimos de Pasantes','Aprobada',3,'2019-08-21 03:19:12','Ángel Urraza 625, Del Valle, 03100, Ciudad de México,México.'),(139,'fotos/2.jpg','Ceih','Mediana','Actividades\r\n-Apoyo en actividades Administrativas\r\n-Conciliación bancaria\r\n-Captura y archivo de documentación\r\n-Reclutamiento\r\nfrecemos:\r\nApoyo económico semanal de $1,000.00\r\nLiberación de practicas o residencia\r\nZona de trabajo: Cumbres del Lago, Juriquilla, Qro\r\nRequerimientos * Educación mínima: Educación superior - Licenciatura\r\nEdad: entre 20 y 25 años\r\nDisponibilidad de viajar: Si\r\nDisponibilidad de cambio de residencia: No','Estudiantes en: TSU o Lic en Administración, Innovación empresarial o afín.','En Proceso','MCO000823CK3 ','Requerimos de Pasantes','En Proceso',3,'2019-08-21 03:21:19',' Av Plateros, Carretas, 76050 Santiago de Querétaro, Qro.'),(140,'fotos/1200x675_9.jpg','IZZI EJECUTIVO SERVICIO A CLIENTES EMPRESARIAL','','OFRECEMOS\r\n\r\nSalario Base\r\nPlan de comisiones y bonos.\r\nCapacitación constante\r\nPosibilidad de crecimiento laboral\r\nPrestaciones superiores de ley\r\nContrato directo por la empresa\r\nFUNCIONES DEL PUESTO:\r\n\r\nResponsable de controlar la cartera de clientes con el propósito de incrementar su satisfacción con el servicio\r\nAtender y gestionar los requerimientos de Back Office de la Cartera de clientes asignada.\r\nSer el punto de contacto principal sobre requerimientos de Back Office (Altas, Bajas, Cambios, Disputas, Aclaraciones, Reclamaciones, Ajustes al Servicio, Facturación, Entrega de Reportes, Entrega de información del servicio instalado, etc)\r\n','Mayor de 30 años\r\nCon experiencia mínima de 4 años en ventas de servicios para PYMES y empresariales.\r\nAltamente enfocado en logro de resultados y gusto por la venta.\r\nBuen manejo de equipos de oficina, Office, presentaciones, estadísticas, etc.\r\nResolución de conflictos\r\n','Si','RLADASASD212','Requerimos de Pasantes','Aprobada',2,'2019-08-21 03:34:38','Iztapalapa, Estado de Mexico , Mexico'),(141,'fotos/1200x675_11.jpg','Stefanini México, S.A. de C.V.','Mediana','En Stefanini proveemos servicios de TI para los diferentes sectores de industria entre los cuales destacan los sectores Financiero, Retail, Telecom, Seguros y Tecnología, entre otros.\r\nDesarrollador BPM\r\n\r\n2 años de experiencia o más en:\r\n\r\n\r\n•	Diseño, desarrollo y mantenimiento de proyectos de BPM\r\n•	Diseñará e implementará activos reutilizables dentro de un proyecto.\r\n•	Uso de las mejores prácticas de BPM para garantizar que los procesos cumplan.\r\n•	Desarrollo de procesos utilizando IBM BPM v8.5\r\n•	Conocimiento de Pruebas (UAT)\r\n•	Comprensión de los conceptos de programación\r\n•	Uso de metodologías agiles\r\n','Somos una empresa líder en el sector de Tecnologías de Información con oficinas corporativas en Sao Paulo Brasil, contamos con más de 21000 profesionales, 96 oficinas en 41 países y 87 ciudades las cuales se encuentran distribuidas de forma estratégica en América Latina, América del Norte, Europa, Oceanía, África y Asia.','Si','STEFFI3123FF','Requerimos de Pasantes','Aprobada',2,'2019-08-21 03:36:48','Blvd. Miguel de Cervantes Saavedra 193, Granada, 11520 Ciudad de México, CDMX'),(142,'fotos/conta.jpg','ORGANIZACION CONTABLE MEXICANA, S.A. DE C.','Mediana','Los requisitos generales son:\r\n•	Manejo de computadora, organización de trabajo, liderazgo\r\n•	Persona que sepa seguir reglas, normas e instrucciones\r\n•	Que conozco de manejo de activos informáticos\r\n•	Dominio completo de Excel\r\nTrabajos principales:\r\n•	Registro de operaciones\r\n•	Trámites de activos\r\n•	Cartas responsivas\r\n•	Inventario físico de mercancías informáticas\r\n•	Control de almacén de activos informáticos\r\n','Se solicita pasante de informática, con al menos 2 años de experiencia en manejo de activos informáticos.','Si','ORGCTAD2109','Requerimos de Pasantes','Aprobada',2,'2019-08-21 03:41:00','Lindavista Norte, Barras 30, Lindavista, 07300 Ciudad de México, CDMX'),(143,'fotos/1200x675_10.jpg','Randstad','Grande','•	Estudiante o pasante de Licenciatura o Ingeniería en ramas administrativas, informática o sistemas computacionales.\r\n•	Nivel de inglés avanzado o nativo (gramar, listening, reading and oral)\r\n•	Capacidad para calcular cifras y cantidades, tales como proporciones, porcentajes, (ponderados) promedios.\r\n•	Excelentes conocimiento y experiencia con Excel.\r\n•	Mínimo 6 meses trabajando en Call Center, atención al cliente. Forzoso\r\n•	Experiencia trabajando con datos, análisis de los mismos y reportes ejecutivos.\r\n•	Disponibilidad para laborar de 11:00 a.m. a 8:00 p.m. Lunes a Domingo (Descanso viernes y sábado).\r\n•	Prestaciones de ley.\r\n','Empresa Internacional con más de 20 años de experiencia en Call Center se encuentra en búsqueda de Analista Bilingüe de Workforce Management , para desempeñar las siguientes funciones:\r\n\r\n•	Para ayudar con la planificación a corto y medio rango basada en el análisis continuo de pronósticos, tendencias, variables de personal y desempeño en tiempo real de operaciones basadas en los principios de gestión de personal para el Call Center.\r\n','Si','RADASDA2314','Requerimos de Pasantes','Aprobada',2,'2019-08-21 03:43:10',' Planta Baja, Av. Insurgentes Sur 1524, Crédito Constructor, 03940 Ciudad de México, CDMX'),(144,'fotos/bussines.jpg','Business intelligence & Customer service','','ACTIVIDADES:\r\n\r\nPlanificar y organizar la obtención sistemática de información (comportamiento de flotillas vehiculares).\r\nAsistencia de negocio (Consultoría) a clientes.\r\nColaborar con el equipo LATAM para el desarrollo de reportes.\r\n\r\nOFRECEMOS:\r\n\r\nTrabajo de Lunes a Viernes, atractivo sueldo, estabilidad laboral y formar parte de una gran empresa Transnacional!!!\r\n','Importante empresa líder a nivel Internacional está buscando tu talento!\r\n\r\nBuscamos Business intelligence & Customer service\r\n\r\nEXPERIENCIA:\r\n\r\nMínimo 3 años en manejo y modelado de bases de datos.\r\nLicenciaturas Económico–Finanzas, Actuario, Industrial e Ing. En sistemas, pasante o titulado.\r\n','Si','INTRFLADA31','Requerimos de Pasantes','Aprobada',2,'2019-08-21 03:47:23','Norte: Avenida Ejército Nacional  Este: Avenida General Mariano Escobedo Oeste: Bulevar Manuel Ávila Camacho'),(145,'fotos/1200x675_13.jpg','TravelNet','Grande','SOLICITA ANALISTA DE SISTEMAS INFORMATICOS\r\n\r\nBuscamos una persona con vocación de servicio, con habilidades de comunicación y capacidad para el trabajo en equipo.\r\n\r\nESCOLARIDAD\r\nLicenciatura en Sistemas Informáticos o Ingeniería Informática (Pasante o Titulado)\r\n\r\nREQUISITOS\r\nSexo: Indistinto\r\nEstado Civil: Indistinto\r\nEdad: 23 – 40 AÑOS\r\n2 años de experiencia\r\nExperiencia Comprobable\r\n\r\n\r\nCONOCIMIENTOS\r\nConocimiento de lenguajes informáticos\r\nExperiencia en programación.\r\nCAPACIDADES Y HABILIDADES\r\n\r\nProactivo,\r\nResponsable,\r\nComprometido,\r\nAutodidacta\r\nEnfocado a resultados\r\nGusto por los retos\r\nCapacidad para trabajar en equipo\r\nFacilidad para detectar problemas y solucionarlos\r\nDinámico\r\nOrganizado\r\nExperiencia Comprobable\r\n\r\n','SISTEMAS MIG Y TRAVEL NET EMPRESAS LÍDER EN SOLUCIONES TECNOLÓGICAS PARA SECTOR TURÍSTICO.','Si','TRAVA3213TLS','Requerimos de Pasantes','Aprobada',2,'2019-08-21 03:50:49','Río Ganges 45, Cuauhtémoc, 06500 Ciudad de México, CDMX'),(146,'fotos/1200x675_7.jpg','Grupo Innova','Grande','Competencias:\r\nProactivo, organizado, trabajo en equipo y responsable.\r\n\r\nRequisitos:\r\nLicenciatura en Informática / Ing. en Sistemas o Afín (Pasante o titulado).\r\n2 años de experiencia\r\nIngles Avanzado\r\nConocimiento en redes, bases, COBIT, VISIO y PROJET\r\n\r\n          Ofrecemos:\r\n\r\n·        Sueldo base (según experiencia)\r\n·        Prestaciones de ley\r\n·        Premio de Lealtad.\r\n·        Bono por cumpleaños.\r\n·        Seguro de Vida y por Accidentes.\r\n·        Estabilidad laboral y buen ambiente de trabajo.\r\n','Empresa líder en ventas de productos por televisión solicita:\r\nPROJECT MANAGER\r\n\r\nFunciones:\r\n·        Diseño de planes de trabajo e identificación de áreas de oportunidad.\r\n·        Manejo de metodología ITIL y COBIT.\r\n·        Gestión de la calidad del servicio que ofrece el área de TI.\r\n·        Ejecución, seguimiento y control.\r\n·        Generación de reportes (diarios, semanales y mensuales) de los tiempos de indisponibilidad de los sistemas.\r\n','Si','INNDAD214VA','Requerimos de Pasantes','Aprobada',2,'2019-08-21 11:58:42','Alcaldía Benito Juárez (Cerca del metro Mixcoac).'),(147,'fotos/descarga (2).jpg','PROCESS MANAGEMENT AND SOLUTION, S.A. DE C.V.','Grande','\r\n•	Apoyo en la planeación, diseño, implementación y ejecución de pruebas en en ambiente de desarrollo y QA, así como en el diseño y ejecución de casos de pruebas manuales.\r\n•	 Creación de casos de prueba, generación y seguimiento de defectos, Escenarios de prueba. Análisis de documentación, pruebas funcionales, pruebas a webservices.\r\n•	Identificación de casos de pruebas\r\n•	Generación de matrices de trazabilidad\r\n•	Conocimientos básicos de Quality Center\r\n\r\nConocimientos básicos de metodología SCRUM\r\n\r\n\r\nIMPORTANTE: ESTARÁN EN TRASLADOS CONSTANTES ENTRE LAS TRES OFICINAS DEL CLIENTE (REFORMA CABALLITO, METRO HIDALGO, COL. EL RELOJ TLALPAN)\r\n\r\nPROYECTO TEMPORAL A 6 MESES PROMEDIO\r\n\r\n','ANALISTAS DE PRUEBAS, TESTERS (URGEN)\r\n08 Ago\r\nNTEGRATE A NUESTRO EQUIPO DE TRABAJO\r\n(PROYECTO)\r\n \r\n \r\nRequisitos:\r\n.    Ing. Sistemas o Informática (pasante o Titulado)\r\n \r\n  3 años de experiencia\r\n','Si','RLMNASD213','Requerimos de Pasantes','Aprobada',2,'2019-08-21 12:03:46',' Félix Parra 175, San José Insurgentes, 03900 Ciudad de México, CDMX'),(148,'fotos/1200x675_6.jpg','Lapsa','Grande','Funciones:\r\n\r\n•	El desarrollo del plan del proyecto\r\n•	La identificación de los requerimientos y el alcance del proyecto\r\n•	La administración de los recursos humanos y materiales, control de tiempos, identificación y control de riesgos.\r\n•	Administración de los costos/presupuesto, el aseguramiento de la calidad.\r\n•	Reporte y evaluación del desempeño del proyecto.\r\n\r\nOfrecemos\r\n\r\n•	Sueldo neto\r\n•	Prestaciones de ley\r\n•	Oportunidad de crecimiento\r\n','LÍDER DE PROYECTO\r\n08 Ago\r\nIngeniería y Alta Productividad S.A de C.V., empresa dedicada al capital del recurso humano con más de veinte años de experiencia en el área financiera, TI y administrativa:\r\n\r\nLÍDER DE PROYECTO\r\n\r\n\r\nRequisitos:\r\n·        Experiencia indispensable en administración de proyectos.\r\n·        Lic. en informática o ingeniería (pasante o titulado)\r\n·        Edad indistinta\r\n','Si','LAWSAD34C34','Requerimos de Pasantes','Aprobada',2,'2019-08-21 12:07:04',' Cto. Historiadores 44-S P.B. Int.  C-101, Cd. Satelite, Naucalpan, C.P: 53100'),(149,'fotos/1200x675_6.jpg','Lapsa','Grande','Funciones:\r\n\r\n•	El desarrollo del plan del proyecto\r\n•	La identificación de los requerimientos y el alcance del proyecto\r\n•	La administración de los recursos humanos y materiales, control de tiempos, identificación y control de riesgos.\r\n•	Administración de los costos/presupuesto, el aseguramiento de la calidad.\r\n•	Reporte y evaluación del desempeño del proyecto.\r\n\r\nOfrecemos\r\n\r\n•	Sueldo neto\r\n•	Prestaciones de ley\r\n•	Oportunidad de crecimiento\r\n','LÍDER DE PROYECTO\r\n08 Ago\r\nIngeniería y Alta Productividad S.A de C.V., empresa dedicada al capital del recurso humano con más de veinte años de experiencia en el área financiera, TI y administrativa:\r\n\r\nLÍDER DE PROYECTO\r\n\r\n\r\nRequisitos:\r\n·        Experiencia indispensable en administración de proyectos.\r\n·        Lic. en informática o ingeniería (pasante o titulado)\r\n·        Edad indistinta\r\n','En Proceso','LAWSAD34C34','Requerimos de Pasantes','En Proceso',3,'2019-08-21 12:07:51',' Cto. Historiadores 44-S P.B. Int.  C-101, Cd. Satelite, Naucalpan, C.P: 53100'),(150,'fotos/1200x675_5.jpg','Compucentro','Grande','Técnico de Implementación\r\n \r\nOFRECEMOS:\r\nSueldo: $ 9,000\r\nPrestaciones de ley\r\nPlan de carrera\r\n \r\nLun a vie 9:00 - 18:00 Sáb 09:00 - 14:00\r\nZona de trabajo: Edo de Mex. (norte)\r\n \r\nRequisitos indispensables:\r\nTécnico o Ingeniero Pasante en sistemas, computo, electrónica\r\nExperiencia mínima de 2 años\r\nSoporte a usuarios\r\n \r\n \r\nConocimientos:\r\nInstalación y configuración de equipos de cómputo Windows 10\r\nManejo de software, drivers y dominio de redes\r\nInstalación y configuración de programas y software\r\nManejo de migración de información en cómputo\r\nConfiguración de impresoras y periféricos \r\n','Técnico de Implementación POR PROYECTO\r\n08 Ago\r\nEmpresa líder en soluciones TI a nivel nacional, te invita a que formes parte de nuestro equipo como:\r\n','Si','CPT32DFGWLC34','Requerimos de Pasantes','Aprobada',2,'2019-08-21 12:10:54','Santa Fe, D. F'),(151,'fotos/1200x675_1.jpg','ASOSA PERSONAL','Grande','Características:\r\nBuena presentación\r\nResponsable\r\nProactivo (a)\r\n\r\nOfrecemos:\r\nSueldo Base\r\nPrestaciones superiores a la ley\r\nOportunidad de crecimiento\r\nExcelente ambiente de trabajo\r\nZona de trabajo: Azcapotzalco\r\nHorario lunes a viernes de 8:00am a 6.00pm\r\nSi cubres con el perfil, postularse por este medio.\r\n','ESPECIALISTA DE INFRAESTRUCTURA\r\n \r\nRequisitos:\r\n\r\nEscolaridad: Ingeniería o Licenciatura en Sistemas Computacionales (pasante o titulado)\r\nExperiencia 4 años recientes y estables en sistemas y 2 en el puesto.\r\n•	Instalar, configurar, mantener, apoyar y proteger las telecomunicaciones, servidores, aplicaciones, bases de datos e infraestructura general.\r\n•	Dar soporte técnico a incidencias de segundo nivel referente a telecomunicaciones, servidores, aplicaciones, bases de datos e infraestructura general.\r\n•	Supervisar el rendimiento disponibilidad y capacidad de telecomunicaciones\r\n•	Realizar oportunamente propuestas de mejora e implementarlas.\r\n•	Instalar, configurar, mantener, apoyar y proteger las telecomunicaciones\r\n','Si','ALDASS9834FLF','Requerimos de Pasantes','Aprobada',2,'2019-08-21 12:15:04','Av. Paseo de la Reforma 87, Tabacalera, 06030 Ciudad de México, CDMX'),(152,'fotos/1200x675_1.jpg','ASOSA PERSONAL','Grande','Características:\r\nBuena presentación\r\nResponsable\r\nProactivo (a)\r\n\r\nOfrecemos:\r\nSueldo Base\r\nPrestaciones superiores a la ley\r\nOportunidad de crecimiento\r\nExcelente ambiente de trabajo\r\nZona de trabajo: Azcapotzalco\r\nHorario lunes a viernes de 8:00am a 6.00pm\r\nSi cubres con el perfil, postularse por este medio.\r\n','ESPECIALISTA DE INFRAESTRUCTURA\r\n \r\nRequisitos:\r\n\r\nEscolaridad: Ingeniería o Licenciatura en Sistemas Computacionales (pasante o titulado)\r\nExperiencia 4 años recientes y estables en sistemas y 2 en el puesto.\r\n•	Instalar, configurar, mantener, apoyar y proteger las telecomunicaciones, servidores, aplicaciones, bases de datos e infraestructura general.\r\n•	Dar soporte técnico a incidencias de segundo nivel referente a telecomunicaciones, servidores, aplicaciones, bases de datos e infraestructura general.\r\n•	Supervisar el rendimiento disponibilidad y capacidad de telecomunicaciones\r\n•	Realizar oportunamente propuestas de mejora e implementarlas.\r\n•	Instalar, configurar, mantener, apoyar y proteger las telecomunicaciones\r\n','En Proceso','ALDASS9834FLF','Requerimos de Pasantes','En Proceso',3,'2019-08-21 12:15:12','Av. Paseo de la Reforma 87, Tabacalera, 06030 Ciudad de México, CDMX'),(153,'fotos/1200x675_12.jpg','Televisa','Grande',' \r\nREQUISITOS:\r\n•	Estudiante de licenciatura.\r\n•	Licenciatura en Comunicación o afin.\r\n•	Disponibilidad para trabajar 4 horas diarias. \r\n•	Disponibilidad para trabajar en el sur.\r\nACTIVIDADES:\r\n•	Apoyo en cabina\r\n•	Investigación de Temas\r\n•	RP con invitados.\r\n•	Streamings (Facebook Lives o Periscope)\r\nCompensación: \r\n•	Está vacante NO TIENE REMUNERACIÓN ECONÓMICA.\r\n•	Constancia de inicio y termino de Prácticas o Servicio Social. \r\n•	Vales de comedor a precio de empleado.\r\n','Comunicacion\r\n\r\nTELEVISA RADIO te brinda la oportunidad de liberar tu Servicio Social o realizar tus Prácticas Profesionales en el programa en Buena Onda.\r\n','Si','TEL721214GK7','Requerimos de Pasantes','Aprobada',2,'2019-08-21 12:17:58','Coyoacán, Distrito Federal');
/*!40000 ALTER TABLE `empresas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `evaluacion_estadia`
--

DROP TABLE IF EXISTS `evaluacion_estadia`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `evaluacion_estadia` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Calificacion` enum('Buena','Muy Buena','Regular','Mala') NOT NULL,
  `Comentarios` varchar(1000) NOT NULL,
  `empresas_id` int(11) NOT NULL,
  `usuarios_id` int(11) NOT NULL,
  `fecha_coment` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_evaluacion_estadia_empresas1_idx` (`empresas_id`),
  KEY `fk_evaluacion_estadia_usuarios1_idx` (`usuarios_id`),
  CONSTRAINT `fk_evaluacion_estadia_empresas1` FOREIGN KEY (`empresas_id`) REFERENCES `empresas` (`id_emp`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `evaluacion_estadia`
--

LOCK TABLES `evaluacion_estadia` WRITE;
/*!40000 ALTER TABLE `evaluacion_estadia` DISABLE KEYS */;
INSERT INTO `evaluacion_estadia` VALUES (1,'Muy Buena','Muy buena empresa',42,18,NULL),(2,'Muy Buena','Muy buena empresa',42,19,NULL),(3,'Regular','Muy buena empresa Muy buena empresa Muy buena empresa Muy buena empresa Muy buena empresa',42,18,NULL),(4,'Regular','qwew ',42,18,NULL),(5,'Regular','qwew ',42,18,NULL),(6,'Muy Buena','adasdas',42,18,NULL),(7,'Muy Buena','adasdas',42,18,NULL),(8,'Muy Buena','adasdas',42,18,NULL),(9,'Muy Buena','adasdas',42,18,NULL),(10,'Muy Buena','adasdas',42,18,NULL),(11,'Muy Buena','adasdas',42,18,NULL),(12,'Muy Buena','adasda',42,18,NULL),(13,'Mala','Prueba',42,18,NULL),(14,'Regular','Prueba Shila jaja',42,18,'2019-08-03 00:40:19'),(15,'Regular','Prueba Shila jaja',42,18,'2019-08-03 00:58:08'),(16,'Regular','Prueba Shila jaja',42,18,'2019-08-03 01:32:58'),(17,'Regular','Prueba Shila jaja',42,18,'2019-08-03 02:56:48'),(18,'Regular','Prueba Shila jaja',42,18,'2019-08-03 02:56:53'),(19,'Regular','Prueba Shila jaja',42,18,'2019-08-03 03:13:14'),(20,'Regular','Prueba Shila jaja',42,18,'2019-08-03 03:13:47'),(21,'Regular','Prueba Shila jaja',42,18,'2019-08-03 03:14:53'),(22,'Regular','Prueba Shila jaja',42,18,'2019-08-03 03:15:09'),(23,'Regular','Prueba Shila jaja',42,18,'2019-08-03 03:15:22'),(24,'Regular','Prueba Shila jaja',42,18,'2019-08-03 03:15:54'),(25,'Regular','Prueba Shila jaja',42,18,'2019-08-03 03:16:35'),(26,'Regular','dasdasdasdas',42,18,'2019-08-03 03:39:36'),(27,'Regular','dasdasdasdas',42,18,'2019-08-03 03:43:04'),(28,'Regular','dasdasdasdas',42,18,'2019-08-03 03:47:09'),(29,'Regular','dasdasdasdas',42,18,'2019-08-03 03:49:01'),(30,'Regular','dasdasdasdas',42,18,'2019-08-03 03:50:07'),(31,'Regular','dasdasdasdas',42,18,'2019-08-03 03:50:22'),(32,'Regular','dasdasdasdas',42,18,'2019-08-03 03:51:35'),(33,'Muy Buena','Esta es una Prueba de que funciona realmente el codigo de guarda mi comentario',42,18,'2019-08-03 05:26:10'),(34,'Mala','Jajajaj me caga esta carrera XD',72,83,'2019-08-03 05:27:35'),(35,'Buena','Hello there',72,88,'2019-08-03 05:32:29'),(36,'Buena','Hello there',72,88,'2019-08-03 05:36:00'),(37,'Muy Buena','Jajajaja buebos',42,18,'2019-08-03 14:22:21'),(38,'Muy Buena','Jajajaj buebos',54,18,'2019-08-03 16:59:02'),(39,'Muy Buena','Jajajaj buebos',54,18,'2019-08-03 17:00:23'),(40,'Buena','Esta shila la empresa jaja xd',105,18,'2019-08-03 17:35:41'),(41,'Muy Buena','JAjajaj Ala verga',42,18,'2019-08-03 21:10:21'),(42,'Muy Buena','Buena Empresa ',153,100,'2019-08-21 15:12:47');
/*!40000 ALTER TABLE `evaluacion_estadia` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `periodo`
--

DROP TABLE IF EXISTS `periodo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `periodo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Fecha_inicio` date NOT NULL,
  `Fecha_fin` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `periodo`
--

LOCK TABLES `periodo` WRITE;
/*!40000 ALTER TABLE `periodo` DISABLE KEYS */;
INSERT INTO `periodo` VALUES (1,'2019-05-01','2019-08-31'),(2,'2020-01-01','2020-01-01'),(3,'2020-05-01','2020-08-31');
/*!40000 ALTER TABLE `periodo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `personal`
--

DROP TABLE IF EXISTS `personal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `personal` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `matricula_trabajador` varchar(45) NOT NULL,
  `nombre_completo` varchar(60) NOT NULL,
  `departamento` varchar(450) NOT NULL,
  `carreras_id` int(11) NOT NULL,
  `usuarios_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_personal_carreras1_idx` (`carreras_id`),
  KEY `fk_personal_usuarios1_idx1` (`usuarios_id`),
  CONSTRAINT `fk_personal_carreras1` FOREIGN KEY (`carreras_id`) REFERENCES `carreras` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_personal_usuarios1` FOREIGN KEY (`usuarios_id`) REFERENCES `usuarios` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `personal`
--

LOCK TABLES `personal` WRITE;
/*!40000 ALTER TABLE `personal` DISABLE KEYS */;
INSERT INTO `personal` VALUES (1,'123645','Mayra Ibarra Santos','Tecnologias de la Información y Comunicación',2,84),(2,'123456','Aurelio Gonzalez Martinez','Area de cordinación de Estadias de Administración',3,101),(3,'123455','Auerelio Gonzalez Martinez','Area de cordinación de Estadias de Administración',3,102);
/*!40000 ALTER TABLE `personal` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `postulaciones`
--

DROP TABLE IF EXISTS `postulaciones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `postulaciones` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Fecha_postulacion` datetime NOT NULL,
  `curriculum_v` varchar(400) NOT NULL,
  `empresas_id` int(11) NOT NULL,
  `usuarios_id` int(11) NOT NULL,
  `estatusPost` enum('En Proceso','Aceptada','Rechazada') NOT NULL,
  `cartaAceptacion` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `usuarios_id_UNIQUE` (`usuarios_id`),
  KEY `fk_postulaciones_empresas1_idx` (`empresas_id`),
  KEY `fk_postulaciones_usuarios1_idx` (`usuarios_id`),
  CONSTRAINT `fk_postulaciones_empresas1` FOREIGN KEY (`empresas_id`) REFERENCES `empresas` (`id_emp`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=82 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `postulaciones`
--

LOCK TABLES `postulaciones` WRITE;
/*!40000 ALTER TABLE `postulaciones` DISABLE KEYS */;
INSERT INTO `postulaciones` VALUES (59,'2019-08-03 17:36:02','documentos/Report.pdf',105,18,'En Proceso',NULL),(67,'2019-08-19 17:10:46','documentos/INEJoseMriaGomezSantos.pdf',43,91,'Aceptada','documentos/PN-16 AUDITORIAS INTERNAS.pdf'),(81,'2019-08-21 15:13:06','documentos/doc.pdf',153,100,'En Proceso',NULL);
/*!40000 ALTER TABLE `postulaciones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `procesos`
--

DROP TABLE IF EXISTS `procesos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `procesos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `periodo_id` int(11) NOT NULL,
  `Nivel` enum('TSU.','Ing.','Licenciatura') DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_Procesos_periodo1_idx` (`periodo_id`),
  CONSTRAINT `fk_Procesos_periodo1` FOREIGN KEY (`periodo_id`) REFERENCES `periodo` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `procesos`
--

LOCK TABLES `procesos` WRITE;
/*!40000 ALTER TABLE `procesos` DISABLE KEYS */;
INSERT INTO `procesos` VALUES (1,1,'TSU.'),(2,2,'Ing.'),(3,3,'Licenciatura');
/*!40000 ALTER TABLE `procesos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `propuesta`
--

DROP TABLE IF EXISTS `propuesta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `propuesta` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Nombre_empresa` varchar(45) NOT NULL,
  `Contacto` varchar(45) NOT NULL,
  `Total_vacantes` varchar(45) NOT NULL,
  `usuarios_id` int(11) NOT NULL,
  `Procesos_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_propuesta_personas1_idx` (`usuarios_id`),
  KEY `fk_propuesta_Procesos1_idx` (`Procesos_id`),
  CONSTRAINT `fk_propuesta_Procesos1` FOREIGN KEY (`Procesos_id`) REFERENCES `procesos` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COMMENT='			';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `propuesta`
--

LOCK TABLES `propuesta` WRITE;
/*!40000 ALTER TABLE `propuesta` DISABLE KEYS */;
INSERT INTO `propuesta` VALUES (7,'UTXJ','7641005949','12',18,2),(8,'Xico TV','2223986471','4',88,2),(9,'TV Azteca CDMX','7641005949','12',18,1);
/*!40000 ALTER TABLE `propuesta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuario_invitado`
--

DROP TABLE IF EXISTS `usuario_invitado`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usuario_invitado` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Nombre_completo` varchar(45) NOT NULL,
  `usuarios_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_usuario_invitado_usuarios1_idx` (`usuarios_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuario_invitado`
--

LOCK TABLES `usuario_invitado` WRITE;
/*!40000 ALTER TABLE `usuario_invitado` DISABLE KEYS */;
/*!40000 ALTER TABLE `usuario_invitado` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuarios`
--

DROP TABLE IF EXISTS `usuarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `correo` varchar(60) NOT NULL,
  `contraseña` varchar(45) NOT NULL,
  `estatus` enum('habilitado','inhabilitado','En Proceso') NOT NULL,
  `tipo_usuario` enum('En Proceso','Personal','Alumno','UsuarioNormal') NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=103 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuarios`
--

LOCK TABLES `usuarios` WRITE;
/*!40000 ALTER TABLE `usuarios` DISABLE KEYS */;
INSERT INTO `usuarios` VALUES (83,'luis_enrique@gmail.com','1234','habilitado','Alumno'),(84,'mayra@gmail.com','12345','inhabilitado','Personal'),(88,'88esmeh@gmail.com','1234','habilitado','Alumno'),(90,'eo12.0914@gmail.com','lisha','habilitado','Alumno'),(91,'america_gomez_santos@hotmail.com','1234','habilitado','Alumno'),(98,'chema9223@gmail.com','12345','habilitado','Alumno'),(99,'josemaria.gomez@utxicotepec.edu.mx','12345','En Proceso','En Proceso'),(100,'israel@hotmail.com','1234','habilitado','Alumno'),(101,'aurelio@gmail.com','1234','habilitado','Personal'),(102,'','','','');
/*!40000 ALTER TABLE `usuarios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'bd_estadia'
--

--
-- Dumping routines for database 'bd_estadia'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-08-21 17:46:15
