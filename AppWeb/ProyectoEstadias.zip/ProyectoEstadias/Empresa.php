<!doctype html>
<html lang="en">
    <head>
                  <?php
include 'php_files/lib_empresas.php';
if ($_GET) {
   if ($_GET['btn'] == "guardar") {
        $calificacion=$_GET['calificacion'];
        $coment=$_GET['comentario'];
        $empresaID=$_GET['id_empresa'];
        $usuarioID=$_GET['id_usuario'];
      ingresaComentario($calificacion,$coment,$empresaID,$usuarioID);
    }
}
?> 
          
<?php
session_start();

?>

   <!-- Required meta tags -->
   <meta charset="utf-8">
   <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
     <title>Catalogo Estadias</title>
   <link rel="icon" href="img/favicon.png">
   <!-- Bootstrap CSS -->
   <link rel="stylesheet" href="css/bootstrap.min.css">
   <!-- animate CSS -->
   <link rel="stylesheet" href="css/animate.css">
   <!-- owl carousel CSS -->
   <link rel="stylesheet" href="css/owl.carousel.min.css">
   <!-- themify CSS -->
   <link rel="stylesheet" href="css/themify-icons.css">
   <!-- flaticon CSS -->
   <link rel="stylesheet" href="css/liner_icon.css">
   <link rel="stylesheet" href="css/search.css">
   <!-- swiper CSS -->
   <link rel="stylesheet" href="css/slick.css">
   <!-- style CSS -->
   <link rel="stylesheet" href="css/style.css">
</head>
<?php
            if(isset($_SESSION['Alumno']) || isset($_SESSION['Personal'] ) || isset($_SESSION['UsuarioNormal'] ) ){
            ?>
<body>
   <!--::header part start::-->
     <header class="main_menu">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-12">
                    <nav class="navbar navbar-expand-lg navbar-light">
                        <a class="navbar-brand" href="index.php"> <img src="login/images/logo_p.png" alt="logo"> </a>
                        <button class="navbar-toggler" type="button" data-toggle="collapse"
                            data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                            aria-expanded="false" aria-label="Toggle navigation">
                            <span class="navbar-toggler-icon"></span>
                        </button>

                        <div class="collapse navbar-collapse main-menu-item justify-content-center"
                            id="navbarSupportedContent">
                            <ul class="navbar-nav">
                                <li class="nav-item active">
                                    <?php 
                                    
                                     if ("Alumno"==$_SESSION['tipoUser']) {
                                         
                                    
                                    
?>
                                    <a class="nav-link" href="index3.php">Home</a>
                                <?php 
                                     } elseif ("Personal"==$_SESSION['tipoUser']) {
                                        
                                 ?>
                                     <a class="nav-link" href="index2.php">Home</a>
                                <?php    
                                    } elseif ("UsuarioNormal"==$_SESSION['tipoUser']) {
                                        
                                 ?>
                                     <a class="nav-link" href="index1.php">Home</a>
                                <?php    
                                    }
                                ?>
                                     
                                       <?php 
                                    
                                     if ("Alumno"==$_SESSION['tipoUser']) {
                                         
                                    
                                    
                                    ?>   
                                     
                                     
                                </li>
                                
                                <li class="nav-item">
                                    <a class="nav-link" href="formularios/PropuestaEmpresa.php">Propuesta Empresa</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="indexEmpresa.php"> Empresas</a>
                                </li>
                                 <?php
                                    } elseif ("Personal"==$_SESSION['tipoUser']) {
                                        
                                        
                                 
                                    ?>
                                      <li class="nav-item">
                                          <a class="nav-link" href="formularios/RegistroU.php">Registro de usuarios</a>
                                    </li>
                                      <li class="nav-item">
                                          <a class="nav-link" href="PropuestasEmp.php">Propuestas de Empresa</a>
                                    </li>
                                      <li class="nav-item">
                                          <a class="nav-link" href="Postulaciones.php">Postulaciones</a>
                                    </li>
                                     <li class="nav-item">
                                    <a class="nav-link" href="indexEmpresa.php"> Empresas</a>
                                </li>
                                   <?php
                                      }
                                   ?> 
                              
                            </ul>
                    </div>
                        <div class="header_social_icon d-none d-sm-block">
                            <ul>
                                <li>
                                    <div id="wrap">
                                        <form action="#" autocomplete="on">
                                            <input id="search" name="search" type="text" placeholder="Search here"><span class="ti-search"></span> 
                                        </form>
                                    </div>
                                </li>
                                   <li><a href="#" class="d-none d-lg-block"><i class="ti-facebook"></i></a></li>
                                    <li><a href="#" class="d-none d-lg-block"> <i class="ti-twitter-alt"></i></a></li>
                                    <li><a href="#" class="d-none d-lg-block"><i class="ti-instagram"></i></a></li>
                                     <li><a href="php_files/logout.php"a class="d-none d-lg-block">Cerrar Sesion <i class="ti-lock"></i></a></li>
                            </ul>
                        </div>
                    </nav>
                </div>
            </div>
        </div>
    </header>
   <!-- Header part end-->

   <!-- breadcrumb start-->
   <section class="breadcrumb breadcrumb_bg">
      <div class="container">
         <div class="row">
            <div class="col-lg-12">
               <div class="breadcrumb_iner text-center">
                    <?php
                 
                              require_once './php_files/lib_empresas.php';
                              
                            if (isset($_GET['id'])) $id = $_GET['id'];
                            else if (isset($_GET['id_empresa'])) 
                                $id = $_GET['id_empresa'];
                            $result= seleccionaEmpresa($id);
                            $fila=$result->fetch_assoc();
                ?>
                  <div class="breadcrumb_iner_item">
                     <h2>Empresa: <?php echo $fila['nombre_e'];?></h2>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </section>
   <!-- breadcrumb start-->
   <!--================Blog Area =================-->
   <section class="blog_area single-post-area all_post section_padding">
      <div class="container">
         <div class="row">
            <div class="col-lg-12 posts-list">
   
               <div class="single-post">
                  <div class="feature-img">
                      <img class="img-fluid" src="<?php echo $fila['imagen_empresa'];?>"  alt="">
                  </div>
                  <div class="blog_details">
                      <h1><strong><?php echo $fila['nombre_e'];?>
                          </strong></h1>
                      <h2>Ubicación: <?php echo $fila['ubicacion'];?>
                      </h2>
                      <h3>Total de vacantes: <?php echo $fila['total_vacantes'];?> </h3>
                     <ul class="blog-info-link mt-3 mb-4">
                          <h4><a href="#"><i class="far fa-user"></i>RFC Empresa: <?php echo $fila['RFC'];?> </a></h4>
                         <h4><a href="#"><i class="far fa-user"></i>Fecha que se subio <?php echo $fila['fecha_upload'];?> </a></h4>
                           
                        
                     </ul>
                     <p class="excert">
                         <strong>Informacion de la empresa:<br> <?php echo $fila['Informacion'];?></strong>
                     </p>
                   
                     <div class="quote-wrapper">
                        <div class="quotes">
                            <strong>   Caracteristicas de la empresa:<br>
                         <?php echo $fila['Informacion'];?></strong>
                        </div>
                         
                         
                     </div>

                     <?php
                                     if ("Alumno"==$_SESSION['tipoUser']) {
                                         echo '<div class="align-self-xl-baseline">
                                <a href="Postulacion.php?id='.$fila['id_emp'].'"><button class="btn btn-danger"> Postularse</button></a>
                         
                     </div>';
                                     }
                     
                     ?>
                     
                     <br>
               </div>
               <div class="navigation-top">
                  <div class="d-sm-flex justify-content-between text-center">
                     <p class="like-info"><span class="align-middle"><i class="far fa-heart"></i></span> Lily and 4
                        people like this</p>
                     <div class="col-sm-4 text-center my-2 my-sm-0">
                        <!-- <p class="comment-count"><span class="align-middle"><i class="far fa-comment"></i></span> 06 Comments</p> -->
                     </div>
                     <ul class="social-icons">
                        <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                        <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                        <li><a href="#"><i class="fab fa-dribbble"></i></a></li>
                        <li><a href="#"><i class="fab fa-behance"></i></a></li>
                     </ul>
                  </div>
   
               <div  class="comments-area col-md-8 left-padding">
                  <?php
                        require_once './php_files/Conecta.php';
                            
                        
                               $sql="SELECT count(*) as Comentarios FROM   evaluacion_estadia ev 
                            join empresas e on e.id_emp=ev.empresas_id where id_emp='".$fila['id_emp']."'";
                                 $con= Conectar();
                              $result= $con->query($sql); 
                              
                              
                              while ($res= mysqli_fetch_array($result)){
                               
                                  
                  ?>
                   <h4><?php echo $res['Comentarios'] ?> Comentarios</h4>
                   <?php
                              }
                   ?>
                  <div class="comment-list">
                       <?php 
                            require_once './php_files/Conecta.php';
                            
                        
                               $sql="
                            SELECT a.nombre_completo,ev.Comentarios,ev.Calificacion,ev.fecha_coment
                            FROM   evaluacion_estadia ev
                           join empresas e on ev.empresas_id=e.id_emp
                           join usuarios u on ev.usuarios_id=u.id
                           join alumnos a on a.usuarios_id=u.id where e.id_emp='".$fila['id_emp']."' order by ev.fecha_coment desc limit 12 ";
                                 $con= Conectar();
                              $result= $con->query($sql); 
                              
                              
                              while ($res= mysqli_fetch_array($result)){
                               
                                  
                              
                            ?>   
                      <div class="single-comment justify-content-between d-flex" style=" background-color:whitesmoke ">
                        <div class="user justify-content-between d-flex">
                           <div class="thumb">
                               <img src="fotos/usuario.png" alt="">
                           </div>
                           <div class="desc">
                                <div class="d-flex align-items-center">
                                    <h5>
                                       <a href="#"> <?php  echo $res['nombre_completo']?> </a>
                                       
                                    </h5>
                                   
                                 </div>
                                <p class="comment">
                                 <strong><?php  echo $res['Comentarios']?></strong> 
                              </p>
                              <p class="comment">
                                   Calificacion:  <strong><?php  echo $res['Calificacion']?></strong>
                              </p>
                              <div class="d-flex justify-content-between">
                               
                                  
                                 <div class="reply-btn">
                                     <p class="date"> Fecha de Comentario: <strong><?php  echo $res['fecha_coment']?></strong> </p>
                                 </div>
                                 
                              </div>
                           </div>
                        </div>
                     </div>
                      <br>
                         <?php 
                            }
                            ?>  
                  </div>


               </div>
         
              <?php if ("Alumno"==$_SESSION['tipoUser']) {
                                
                            ?>     
               <div class="comment-form">
                  <h4>Comenta Aqui</h4>
                  <form class="form-contact comment_form" <?php echo 'action="Empresa.php?id='.$fila['id_emp'].'"&'; ?>  id="comentario">
                     <div class="row">
                        <a  <?php echo 'href="Empresa.php?id='.$fila['id_emp'].'"'; ?> ></a> 
                        <input   type="hidden" name="id_usuario" id="id_usuario" class="form-control" value="<?php echo "".$_SESSION['usuario_id']."";?>"/>
                        <input  type="hidden"   name="id_empresa" id="id_usuario" class="form-control" value="<?php echo "".$fila['id_emp'].""; ?>"/>
                        <div class="col-12">
                           <div class="form-group">
                              <textarea class="form-control w-100" name="comentario" id="cometario" cols="30" rows="9"
                                 placeholder="Escribe tu comentario"></textarea>
                           </div>
                        </div>
                    <div class="col-12">
                           <div class="form-group">
                               <select name="calificacion" id="calificacion" class="dropdown-item" style="border: #000">
                                                      <option value="0">
                                                       Selecciona una opción
                                                    </option>
                                                    <option value="Buena">
                                                       Buena
                                                    </option>
                                                    <option value="Muy buena">
                                                       Muy buena
                                                    </option>
                                                    <option value="Regular" >
                                                     Regular
                                                    </option>
                                                    <option value="Mala" >
                                                    Mala
                                                    </option>
                                                </select>
                           </div>
                        </div>
                     </div>
                     <div class="load_btn">
                       <button type="submit" name="btn" value="guardar" class=" btn-danger btn-lg">Enviar comentario</button>
                       
                     </div>
                  </form>
               </div>
                   
              <?php } ?>       
            </div>

         </div>
      </div>
   </section>
   <!--================Blog Area end =================-->

   <!-- footer part start-->
    <footer class="footer-area">
            <div class="container">
                <center>
                <div class="row">
                    <div class="col-xl-4 col-md-4 col-sm-6">
                        <div class="single-footer-widget footer_1">
                            <img src="login/images/group digital logo_p.png" alt="">
                        </div>
                    </div>
                    <div class="col-xl-4 col-md-4 col-sm-6">
                        <div class="single-footer-widget footer_2">
                            <h4>Contactanos</h4>
                            <div class="contact_info">
                                <span class="ti-home"></span>
                                <h5>Av. Universidad Tecnológica</h5>
                                <p>#1000, Col.Tierra Negra Xicotepec de Juárez, Puebla C.P.73080</p>
                            </div>
                            <div class="contact_info">
                                <span class="ti-headphone-alt"></span>
                                <h5>01 (764) 764 5240 y 764 5252</h5>
                            </div>
                        </div>
                    </div>
                </div>
                </center>
                <div class="row align-items-center">
                    <div class="col-lg-12">
                        <div class="copyright_part_text text-center">
                            <p class="footer-text m-0"><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                                Copyright &copy;<script>document.write(new Date().getFullYear());</script> <i class="ti-heart" aria-hidden="true"></i> por <a href="https://colorlib.com" target="_blank">GROUP DIGITAL</a>
                                <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. --></p>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
   <!-- footer part end-->
     <?php
            }else{
                header("Location: http://localhost/ProyectoEstadias/Login.php ");
            }
            ?>
   <!-- jquery plugins here-->
   <!-- jquery -->
   <script src="js/jquery-1.12.1.min.js"></script>
   <!-- popper js -->
   <script src="js/popper.min.js"></script>
   <!-- bootstrap js -->
   <script src="js/bootstrap.min.js"></script>
   <!-- custom js -->
   <script src="js/custom.js"></script>
</body>

</html>