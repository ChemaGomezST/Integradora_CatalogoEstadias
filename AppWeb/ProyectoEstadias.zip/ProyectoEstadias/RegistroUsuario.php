
<?php
include './php_files/libreria.php';
if ($_POST) {
    if ($_POST['btn'] == "guardar") {
        $correo = $_POST['email'];
        $contraseña = $_POST['psw'];
        $estatus ="En Proceso";
        $tipo_usuario = "En Proceso";
        GuardarUsuario($correo, $contraseña, $estatus, $tipo_usuario);
        
    }
    }

?>
<!DOCTYPE html>

<html lang="en">

    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <title>Estadias</title>
        <link rel="icon" href="img/favicon.png">
        <!-- Bootstrap CSS -->
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <!-- animate CSS -->
        <link rel="stylesheet" href="css/animate.css">
        <!-- owl carousel CSS -->
        <link rel="stylesheet" href="css/owl.carousel.min.css">
        <!-- themify CSS -->
        <link rel="stylesheet" href="css/themify-icons.css">
        <!-- flaticon CSS -->
        <link rel="stylesheet" href="css/liner_icon.css">
        <link rel="stylesheet" href="css/search.css">
        <!-- swiper CSS -->
        <link rel="stylesheet" href="css/slick.css">
        <!-- style CSS -->
        <link rel="stylesheet" href="css/style.css">
    </head>

    <body>

        <!--::header part start::-->
        <header class="main_menu">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-12">
                        <nav class="navbar navbar-expand-lg navbar-light">
                            <a class="navbar-brand" href="index1.php"> <img src="login/images/logo_p.png" alt="logo"> </a>
                            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
                                    aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                                <span class="navbar-toggler-icon"></span>
                            </button>

                            <div class="collapse navbar-collapse main-menu-item justify-content-center" id="navbarSupportedContent">
                                <ul class="navbar-nav">
                                     <li class="nav-item active">
                                         <a class="nav-link" href="index1.php">Regresar</a>
                                    </li>
                                    
                                   
                                   
                                </ul>
                            </div>
                            
                        </nav>
                    </div>
                </div>
            </div>
        </header>
        <!-- Header part end-->

        <!-- breadcrumb start-->
        <section class="breadcrumb breadcrumb_bg">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="breadcrumb_iner text-center">
                            <div class="breadcrumb_iner_item">
                                <h2>Registro Usuario</h2>
                                <hr style="broder: 1px;">
                                <h4><strong>Registrate Aqui, a la brevedad se dara de alta su cuenta,favor de ponerse en contacto con el Administrador</strong></h4>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- breadcrumb start-->

        <section>
       
            <div class="container mt-4">
                <form action="RegistroUsuario.php" method="post"   class="popup-form" style="background-color: #fff;
                max-width: 1600px; margin: 20px auto 0; padding: 90px; color: #218838; box-shadow: 8px 8px 8px rgba(0,0,0,0.2);">
                    <div class="row">
                        <div id="msgContactSubmit" class="hidden"></div>
                        
                        <!-- end form-group -->
                        <div class="form-group col-sm-10">
                            <div class="help-block with-errors"></div>
                            <i class="fa fa-user"></i> <label for="email"><strong>Correo</strong></label>
                            <input required="" type="text" placeholder="Correo" name="email" id="email" class="form-control" />

                        </div><!-- end form-group -->
                        <div class="form-group col-sm-10">
                            <div class="help-block with-errors"></div>
                            <i class="fa fa-user"></i> <label for="psw"><strong>Contraseña</strong></label>
                            <input required="" type="password" placeholder="Contraseña" name="psw" id="psw" class="form-control" />

                        </div><!-- end form-group -->

                       
                         <div class="form-group last col-sm-12" style="text-align: center;">
                                <button type="submit" name="btn" value="guardar" class="btn-block btn-success btn-lg">Guardar</button>
                            </div>

                     

                        <div class="clearfix"></div>
                    </div><!-- end row -->
                </form><!-- end form -->
            </div>
        </section>



        <!-- ================ contact section start ================= -->
        <section class="contact-section section_padding">
            <div class="container">
                <div class="d-none d-sm-block mb-5 pb-4">
                    <div id="map" style="height: 480px;"></div>
                    <script>
                        function initMap() {
                            var uluru = {
                                lat: -25.363,
                                lng: 131.044
                            };
                            var grayStyles = [{
                                    featureType: "all",
                                    stylers: [{
                                            saturation: -90
                                        },
                                        {
                                            lightness: 50
                                        }
                                    ]
                                },
                                {
                                    elementType: 'labels.text.fill',
                                    stylers: [{
                                            color: '#ccdee9'
                                        }]
                                }
                            ];
                            var map = new google.maps.Map(document.getElementById('map'), {
                                center: {
                                    lat: -31.197,
                                    lng: 150.744
                                },
                                zoom: 9,
                                styles: grayStyles,
                                scrollwheel: false
                            });
                        }
                    </script>

                </div>
            </div>
        </section>
        <!-- ================ contact section end ================= -->
<footer class="footer-area">
            <div class="container">
                <center>
                <div class="row">
                    <div class="col-xl-4 col-md-4 col-sm-6">
                        <div class="single-footer-widget footer_1">
                            <img src="login/images/group digital logo_p.png" alt="">
                        </div>
                    </div>
                    <div class="col-xl-4 col-md-4 col-sm-6">
                        <div class="single-footer-widget footer_2">
                            <h4>Contactanos</h4>
                            <div class="contact_info">
                                <span class="ti-home"></span>
                                <h5>Av. Universidad Tecnológica</h5>
                                <p>#1000, Col.Tierra Negra Xicotepec de Juárez, Puebla C.P.73080</p>
                            </div>
                            <div class="contact_info">
                                <span class="ti-headphone-alt"></span>
                                <h5>01 (764) 764 5240 y 764 5252</h5>
                            </div>
                        </div>
                    </div>
                </div>
                </center>
                <div class="row align-items-center">
                    <div class="col-lg-12">
                        <div class="copyright_part_text text-center">
                            <p class="footer-text m-0"><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                                Copyright &copy;<script>document.write(new Date().getFullYear());</script> <i class="ti-heart" aria-hidden="true"></i> por <a href="https://colorlib.com" target="_blank">GROUP DIGITAL</a>
                                <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. --></p>
                        </div>
                    </div>
                </div>
            </div>
        </footer>

        <!-- jquery plugins here-->
        <!-- jquery -->
        <script src="js/jquery-1.12.1.min.js"></script>
        <!-- popper js -->
        <script src="js/popper.min.js"></script>
        <!-- bootstrap js -->
        <script src="js/bootstrap.min.js"></script>
        <!-- particles js -->
        <script src="js/contact.js"></script>
        <!-- ajaxchimp js -->
        <script src="js/jquery.ajaxchimp.min.js"></script>
        <!-- validate js -->
        <script src="js/jquery.validate.min.js"></script>
        <!-- form js -->
        <script src="js/jquery.form.js"></script>
        <script src="js/mail-script.js"></script>
        <!-- custom js -->
        <script src="js/custom.js"></script>
    </body>

</html>

