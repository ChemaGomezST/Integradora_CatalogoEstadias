<!doctype html>

<?php
session_start();

?>

<html lang="en">

    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <title>Catalogo Estadias ||  <?php echo "".$_SESSION['tipoUser']."";?></title>
        <link rel="icon" href="img/favicon.png">
        <!-- Bootstrap CSS -->
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <!-- animate CSS -->
        <link rel="stylesheet" href="css/animate.css">
        <!-- owl carousel CSS -->
        <link rel="stylesheet" href="css/owl.carousel.min.css">
        <!-- themify CSS -->
        <link rel="stylesheet" href="css/themify-icons.css">
        <!-- flaticon CSS -->
        <link rel="stylesheet" href="css/liner_icon.css">
        <link rel="stylesheet" href="css/search.css">
        <!-- style CSS -->
        <link rel="stylesheet" href="css/style.css">
    </head>
<?php
            if(isset($_SESSION['Personal'])){
            ?>

    <body>
        <!--::header part start::-->
        <header class="main_menu">
      
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-12">
                        <nav class="navbar navbar-expand-lg navbar-light">
                            <a class="navbar-brand" href="#"> <img src="login/images/logo_p.png" alt="logo"> </a>
                            <button class="navbar-toggler" type="button" data-toggle="collapse"
                                    data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                                    aria-expanded="false" aria-label="Toggle navigation">
                                <span class="navbar-toggler-icon"></span>
                            </button>

                            <div class="collapse navbar-collapse main-menu-item justify-content-center"
                                 id="navbarSupportedContent">
                                <ul class="navbar-nav">
                                    
                                    <li class="nav-item">
                                        <a class="nav-link" href="indexEmpresa.php">Empresas</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="Registro_Empresas.php">Registro de empresas</a>
                                    </li>
                                      <li class="nav-item">
                                          <a class="nav-link" href="formularios/RegistroU.php">Registro de usuarios</a>
                                    </li>
                                      <li class="nav-item">
                                          <a class="nav-link" href="PropuestasEmp.php">Propuestas de Empresa</a>
                                    </li>
                                      <li class="nav-item">
                                          <a class="nav-link" href="Postulaciones.php">Postulaciones</a>
                                    </li>
<!--                                    <li class="nav-item">
                                        <a class="nav-link" href="formularios/Postulacion.php">Postulación</a>
                                    </li>
                             -->
                                </ul>
                            </div>
                            <div class="header_social_icon d-none d-sm-block">
                                <ul>
                                    <li><a href="php_files/logout.php"a class="d-none d-lg-block">Cerrar Sesión<i class="ti-lock"></i></a></li>
                                </ul>
                            </div>
                        </nav>
                    </div>
                </div>
            </div>
        </header>
        <!-- Header part end-->

        <!-- banner post start-->
        <section class="banner_post">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="banner_post_1 banner_post_bg_1">
                        </div>
                        <div class="banner_post_2 banner_post_bg_2">
                            <div class="banner_post_iner">
                                <a href="#"><h2>Universidad Tecnológica de Xicotepec de Juárez </h2></a>  </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- banner post end-->

        <!-- feature_post start-->
        <section class="feature_post">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="single_feature_post post_1">
                            <img src="img/casos_exito/xcaret.jpg" alt="">
                            <div class="post_text_1 pr_30">
                                <h5>Tecnologías de la información</h5>
                                <a href="1.html">
                                    <h3>Deja de preocuparte por los baches de la carretera y celebra el viaje...</h3>
                                </a>
                                <p><span> Playa del Carmen, Quintana Roo, México.</span> </p>
                                
                            </div>
                        </div>
                        <div class="single_feature_post post_1 d-block d-sm-none d-lg-block">
                            <div class="post_text_1 pl_pr_30">
                                <h5>Tecnologías de la información</h5>
                                <a href="2.html">
                                    <h3>No hay secretos para el éxito...</h3>
                                </a>
                                <p><span>Xcaret, Playa del Carmen, Quintana Roo</span></p>
                                
                            </div>
                            <img src="img/casos_exito/66802267_2490985420953162_7824120087509467136_n.jpg" alt="">
                        </div>
                        <div class="single_feature_post post_1">
                            <img src="img/casos_exito/36233433_1901806513204392_7239172995225223168_n.jpg" alt="">
                            <div class="post_text_1 pl_pr_30">
                                <h5>Tecnologías de la información</h5>
                                <a href="3.html">
                                    <h3>El mundo es un libro y aquellos que no viajan solo leen una página...</h3>
                                </a>
                                <p><span>El Instituto Politécnico Nacional</span></p>
                                
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-12">
                        <div class="single_feature_post post_1">
                            <img src="img/casos_exito/65485412_2458657910852580_8238532956390424576_n.jpg" alt="">
                            <div class="post_text_1 pr_30">
                                <h5>Tecnologías de la información</h5>
                                <a href="4.html">
                                    <h3>Viajar te deja sin palabras y después te convierte en un narrador de historias...</h3>
                                </a>
                                <p><span>Universidad del Valle en Colombia</span> </p>
                                
                            </div>
                        </div>
                        <div class="single_feature_post post_1 d-block d-sm-none d-lg-block">
                            <div class="post_text_1 pl_pr_30">
                                <h5>Tecnologías de la información</h5>
                                <a href="5.html">
                                    <h3>No hay secretos para el éxito...</h3>
                                </a>
                                <p><span>Culiacan, Sinaloa</span></p>
                                
                            </div>
                            <img src="img/casos_exito/36309648_1904823899569320_3535161802943889408_n.png" alt="">
                        </div>
                        <div class="single_feature_post post_1">
                            <img src="img/casos_exito/35886330_1890756627642714_4899265685558919168_n.jpg" alt="">
                            <div class="post_text_1 pl_pr_30">
                                <h5>Tecnologías de la información</h5>
                                <a href="6.html">
                                    <h3>Mantente alejado de aquellas personas que tratan de menos preciar tus ambiciones...</h3>
                                </a>
                                <p><span>Xcaret, Playa del Carmen, Quintana Roo</span></p>
                                
                            </div>
                        </div>
                    </div>
                    
                </div>
            </div>
        </section>
        <!-- feature_post end-->

        <!-- border_top start-->
        <div class="border_top"></div>
        <!-- border_top end-->

        <!-- border_top start-->
        <div class="border_top"></div>
        <!-- border_top end-->

        <!-- feature_post start-->

        <!-- feature_post end-->

        <!-- footer part start-->
       <footer class="footer-area">
            <div class="container">
                <center>
                <div class="row">
                    <div class="col-xl-4 col-md-4 col-sm-6">
                        <div class="single-footer-widget footer_1">
                            <img src="login/images/group digital logo_p.png" alt="">
                        </div>
                    </div>
                    <div class="col-xl-4 col-md-4 col-sm-6">
                        <div class="single-footer-widget footer_2">
                            <h4>Contactanos</h4>
                            <div class="contact_info">
                                <span class="ti-home"></span>
                                <h5>Av. Universidad Tecnológica</h5>
                                <p>#1000, Col.Tierra Negra Xicotepec de Juárez, Puebla C.P.73080</p>
                            </div>
                            <div class="contact_info">
                                <span class="ti-headphone-alt"></span>
                                <h5>01 (764) 764 5240 y 764 5252</h5>
                            </div>
                        </div>
                    </div>
                </div>
                </center>
                <div class="row align-items-center">
                    <div class="col-lg-12">
                        <div class="copyright_part_text text-center">
                            <p class="footer-text m-0"><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                                Copyright &copy;<script>document.write(new Date().getFullYear());</script> <i class="ti-heart" aria-hidden="true"></i> por <a href="https://colorlib.com" target="_blank">GROUP DIGITAL</a>
                                <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. --></p>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
        <?php
            }else{
                header("Location: http://localhost/ProyectoEstadias/Login.php ");
            }
            ?>
        <!-- footer part end-->

        <!-- jquery plugins here-->
        <!-- jquery -->
        <script src="js/jquery-1.12.1.min.js"></script>
        <!-- popper js -->
        <script src="js/popper.min.js"></script>
        <!-- bootstrap js -->
        <script src="js/bootstrap.min.js"></script>
        <!-- custom js -->
        <script src="js/custom.js"></script>
    </body>

</html>