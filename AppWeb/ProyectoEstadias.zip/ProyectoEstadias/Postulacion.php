<!doctype html>
<html lang="en">
<?php
session_start();

?>
    
    <?php
include 'php_files/lib_empresas.php';
if ($_POST) {
    if ($_POST['btn'] == "guardar") {
$doc=$_FILES["doc"]["name"];
$ruta=$_FILES["doc"]["tmp_name"];
$destino="documentos/".$doc;
copy($ruta,$destino);
$empresa_id=$_POST['empresaID'];
$usuario_id=$_POST['usuarioID'];

InsertaPostulación($destino,$empresa_id,$usuario_id);    
    }
}
?>   

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Estadias</title>
  <link rel="icon" href="img/favicon.png">
  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <!-- animate CSS -->
  <link rel="stylesheet" href="css/animate.css">
  <!-- owl carousel CSS -->
  <link rel="stylesheet" href="css/owl.carousel.min.css">
  <!-- themify CSS -->
  <link rel="stylesheet" href="css/themify-icons.css">
  <!-- flaticon CSS -->
  <link rel="stylesheet" href="css/liner_icon.css">
  <link rel="stylesheet" href="css/search.css">
  <!-- swiper CSS -->
  <link rel="stylesheet" href="css/slick.css">
  <!-- style CSS -->
  <link rel="stylesheet" href="css/style.css">
</head>
<?php
            if(isset($_SESSION['Alumno'])){
            ?>
<body>
  <!--::header part start::-->
  <header class="main_menu">
    <div class="container">
      <div class="row align-items-center">
        <div class="col-lg-12">
          <nav class="navbar navbar-expand-lg navbar-light">
              <a class="navbar-brand" href="index3.php"> <img src="login/images/logo_p.png" alt="logo"> </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
              aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
              <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse main-menu-item justify-content-center" id="navbarSupportedContent">
              <ul class="navbar-nav">
                <li class="nav-item active">
                    <a class="nav-link" href="index3.php">Inicio</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="indexEmpresa.php">Empresas</a>
                                    </li>
                                    
                                    <li class="nav-item">
                                        <a class="nav-link" href="formularios/PropuestaEmpresa.php">Propuesta</a>
                                    </li>
                                    <li class="nav-item dropdown">
                                    <a class="nav-link" href="">Salir</a>
                  <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                    <a class="dropdown-item" href="single-blog.html">Single blog</a>
                    <a class="dropdown-item" href="elements.html">elements</a>
                  </div>
                </li>
              </ul>
            </div>
            <div class="header_social_icon d-none d-sm-block">
              <ul>
             
                <li><a href="php_files/logout.php"a class="d-none d-lg-block">Cerrar Sesion <i class="ti-lock"></i></a></li>
              </ul>
            </div>
          </nav>
        </div>
      </div>
    </div>
  </header>
  <!-- Header part end-->
    <?php
                 
                              require_once './php_files/lib_empresas.php';
                              
                      $id = $_GET['id'];        
                             $result= seleccionaEmpresa($id);
                             $fila=$result->fetch_assoc();
                ?>
  
  
  <!-- breadcrumb start-->
  <section class="breadcrumb breadcrumb_bg">
    <div class="container">
      <div class="row">
        <div class="col-lg-12">
          <div class="breadcrumb_iner text-center">
            <div class="breadcrumb_iner_item">
              <h1>Postulación ala empresa: <?php echo "".$fila['nombre_e']."";?> </h1>
              
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- breadcrumb start-->
  
  <section>
  <div class="container mt-4">
      
      <form id="Postulacionn" <?php echo 'action="Postulacion.php?id='.$fila['id_emp'].'"'; ?> method="post" enctype="multipart/form-data"  class="popup-form" >

              <div class="row">
                  <div id="" class="hidden"></div>
                  <input  type="hidden" name="usuarioID" id="id_usuario" class="form-control" value="<?php echo "".$_SESSION['usuario_id'].""; ?>"/>
                  <input  type="hidden"  name="empresaID" id="id_u" class="form-control" value="<?php echo "".$fila['id_emp'].""; ?>"/>
                  <div     class="form-group col-sm-6">
                      <div class="help-block with-errors"></div>
                      <i class="fa fa-user"></i> <label for="doc"><strong>Documento</strong></label>
                      <input name="doc" id="doc" accept="application/pdf" type="file" />


                  </div>


                  <div class="form-group last col-sm-12" style="text-align: center;">
                      <button type="submit" name="btn" value="guardar" class="btn-block btn-success btn-lg">Subir Archivo</button>
                  </div>
                  <div class="clearfix"></div>
              </div><!-- end row -->
          </form><!-- end form -->
  </div>
  </section>
  
  
  
  <!-- ================ contact section start ================= -->
  <section class="contact-section section_padding">
    <div class="container">
      <div class="d-none d-sm-block mb-5 pb-4">
        <div id="map" style="height: 480px;"></div>
        <script>
          function initMap() {
            var uluru = {
              lat: -25.363,
              lng: 131.044
            };
            var grayStyles = [{
                featureType: "all",
                stylers: [{
                    saturation: -90
                  },
                  {
                    lightness: 50
                  }
                ]
              },
              {
                elementType: 'labels.text.fill',
                stylers: [{
                  color: '#ccdee9'
                }]
              }
            ];
            var map = new google.maps.Map(document.getElementById('map'), {
              center: {
                lat: -31.197,
                lng: 150.744
              },
              zoom: 9,
              styles: grayStyles,
              scrollwheel: false
            });
          }
        </script>
       
      </div>


      <div class="row">
        <div class="col-12">
          <h2 class="contact-title">Get in Touch</h2>
        </div>
        <div class="col-lg-8">
          <form class="form-contact contact_form" action="contact_process.php" method="post" id="contactForm"
            novalidate="novalidate">
            <div class="row">
              <div class="col-12">
                <div class="form-group">

                  <textarea class="form-control w-100" name="message" id="message" cols="30" rows="9"
                    onfocus="this.placeholder = ''" onblur="this.placeholder = 'Enter Message'"
                    placeholder='Enter Message'></textarea>
                </div>
              </div>
              <div class="col-sm-6">
                <div class="form-group">
                  <input class="form-control" name="name" id="name" type="text" onfocus="this.placeholder = ''"
                    onblur="this.placeholder = 'Enter your name'" placeholder='Enter your name'>
                </div>
              </div>
              <div class="col-sm-6">
                <div class="form-group">
                  <input class="form-control" name="email" id="email" type="email" onfocus="this.placeholder = ''"
                    onblur="this.placeholder = 'Enter email address'" placeholder='Enter email address'>
                </div>
              </div>
              <div class="col-12">
                <div class="form-group">
                  <input class="form-control" name="subject" id="subject" type="text" onfocus="this.placeholder = ''"
                    onblur="this.placeholder = 'Enter Subject'" placeholder='Enter Subject'>
                </div>
              </div>
            </div>
            <div class="load_btn">
              <a href="#" class="btn_1">Send Message <i class="ti-angle-right"></i></a>
            </div>
          </form>
        </div>
        <div class="col-lg-4">
          <div class="media contact-info">
            <span class="contact-info__icon"><i class="ti-home"></i></span>
            <div class="media-body">
              <h3>Buttonwood, California.</h3>
              <p>Rosemead, CA 91770</p>
            </div>
          </div>
          <div class="media contact-info">
            <span class="contact-info__icon"><i class="ti-tablet"></i></span>
            <div class="media-body">
              <h3>00 (440) 9865 562</h3>
              <p>Mon to Fri 9am to 6pm</p>
            </div>
          </div>
          <div class="media contact-info">
            <span class="contact-info__icon"><i class="ti-email"></i></span>
            <div class="media-body">
              <h3>support@colorlib.com</h3>
              <p>Send us your query anytime!</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- ================ contact section end ================= -->

  <!-- footer part start-->
   <footer class="footer-area">
            <div class="container">
                <center>
                <div class="row">
                    <div class="col-xl-4 col-md-4 col-sm-6">
                        <div class="single-footer-widget footer_1">
                            <img src="login/images/group digital logo_p.png" alt="">
                        </div>
                    </div>
                    <div class="col-xl-4 col-md-4 col-sm-6">
                        <div class="single-footer-widget footer_2">
                            <h4>Contactanos</h4>
                            <div class="contact_info">
                                <span class="ti-home"></span>
                                <h5>Av. Universidad Tecnológica</h5>
                                <p>#1000, Col.Tierra Negra Xicotepec de Juárez, Puebla C.P.73080</p>
                            </div>
                            <div class="contact_info">
                                <span class="ti-headphone-alt"></span>
                                <h5>01 (764) 764 5240 y 764 5252</h5>
                            </div>
                        </div>
                    </div>
                </div>
                </center>
                <div class="row align-items-center">
                    <div class="col-lg-12">
                        <div class="copyright_part_text text-center">
                            <p class="footer-text m-0"><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                                Copyright &copy;<script>document.write(new Date().getFullYear());</script> <i class="ti-heart" aria-hidden="true"></i> por <a href="https://colorlib.com" target="_blank">GROUP DIGITAL</a>
                                <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. --></p>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
  <!-- footer part end-->
 <?php
            }else{
                header("Location: http://localhost/ProyectoEstadias/Login.php ");
            }
            ?>
  <!-- jquery plugins here-->
  <!-- jquery -->
  <script src="js/jquery-1.12.1.min.js"></script>
  <!-- popper js -->
  <script src="js/popper.min.js"></script>
  <!-- bootstrap js -->
  <script src="js/bootstrap.min.js"></script>
  <!-- particles js -->
  <script src="js/contact.js"></script>
  <!-- ajaxchimp js -->
  <script src="js/jquery.ajaxchimp.min.js"></script>
  <!-- validate js -->
  <script src="js/jquery.validate.min.js"></script>
  <!-- form js -->
  <script src="js/jquery.form.js"></script>
  <script src="js/mail-script.js"></script>
  <!-- custom js -->
  <script src="js/custom.js"></script>
</body>

</html>
