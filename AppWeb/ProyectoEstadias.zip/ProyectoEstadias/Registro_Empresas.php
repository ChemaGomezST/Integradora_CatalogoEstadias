<!DOCTYPE html>
<?php
session_start();

?>
    <?php
include 'php_files/lib_empresas.php';
if ($_POST) {
    if ($_POST['btn'] == "guardar") {
$foto=$_FILES["foto"]["name"];
$ruta=$_FILES["foto"]["tmp_name"];
$destino="fotos/".$foto;
copy($ruta,$destino);
$nombreE=$_POST['nomE'];
$tamaño=$_POST['CbotamañoE'];
$caracteristicas=$_POST['caract'];
$informacion=$_POST['info'];
$vinculada="En Proceso";
$RFC=$_POST['rfc'];
$total_vacantes="Requerimos de Pasantes";
$estatusEmp="En Proceso";
$ubicacion=$_POST['ubicacion'];
$carrera_id=$_POST['cbx_carrera'];

ingresaEmpresa($destino,$nombreE,$tamaño,$caracteristicas,$informacion,$vinculada,$RFC,$total_vacantes,$estatusEmp,$carrera_id,$ubicacion);    
    }
}
?>
 



<html lang="en">

    <head>
        
       
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <title>Registro de Empresas</title>
        <link rel="icon" href="">
        <!-- Bootstrap CSS -->
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <!-- animate CSS -->
        <link rel="stylesheet" href="css/animate.css">
        <!-- owl carousel CSS -->
        <link rel="stylesheet" href="css/owl.carousel.min.css">
        <!-- themify CSS -->
        <link rel="stylesheet" href="css/themify-icons.css">
        <!-- flaticon CSS -->
        <link rel="stylesheet" href="css/liner_icon.css">
        <link rel="stylesheet" href="css/search.css">
        <!-- swiper CSS -->
        <link rel="stylesheet" href="css/slick.css">
        <!-- style CSS -->
        <link rel="stylesheet" href="css/style.css">
    </head>
<?php
            if(isset($_SESSION['Alumno']) || isset($_SESSION['Personal'] )){
            ?>
    <body>
        <!--::header part start::-->
        <header class="main_menu">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-12">
                        <nav class="navbar navbar-expand-lg navbar-light">
                            <?php
                             if ("Alumno"==$_SESSION['tipoUser']) {
                                         
                                    
                            ?>
                            <a class="navbar-brand" href="index3.php"> <img src="login/images/logo_p.png" alt="logo"> </a>
                           <?php 
                                     } elseif ("Personal"==$_SESSION['tipoUser']) {
                                        
                                 ?>
                             <a class="navbar-brand" href="index2.php"> <img src="login/images/logo_p.png" alt="logo"> </a>
                            <?php
                                     }
                            ?>
                            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
                                    aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                                <span class="navbar-toggler-icon"></span>
                            </button>

                            <div class="collapse navbar-collapse main-menu-item justify-content-center" id="navbarSupportedContent">
                                  <ul class="navbar-nav">
                                    <li class="nav-item active">
                                   <li class="nav-item active">
                                          <?php 
                                    
                                     if ("Alumno"==$_SESSION['tipoUser']) {
                                         
                                    
                                    
?>
                                    <a class="nav-link" href="index3.php">Home</a>
                                <?php 
                                     } elseif ("Personal"==$_SESSION['tipoUser']) {
                                        
                                 ?>
                                     <a class="nav-link" href="index2.php">Home</a>
                                <?php    
                                    } elseif ("UsuarioNormal"==$_SESSION['tipoUser']) {
                                        
                                 ?>
                                     <a class="nav-link" href="index1.php">Home</a>
                                <?php    
                                    }
                                ?>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="indexEmpresa.php">Empresas</a>
                                    </li>
                                  
                                    <?php
                                    if  ("Personal"==$_SESSION['tipoUser']) {
                                        
                                 
                                    ?>
                                      <li class="nav-item">
                                          <a class="nav-link" href="formularios/RegistroU.php">Registro de usuarios</a>
                                    </li>
                                      <li class="nav-item">
                                          <a class="nav-link" href="PropuestasEmp.php">Propuestas de Empresa</a>
                                    </li>
                                      <li class="nav-item">
                                          <a class="nav-link" href="Postulaciones.php">Postulaciones</a>
                                    </li>
                                   <?php
                                      }
                                   ?> 
                                </ul>
                            </div>
                            <div class="header_social_icon d-none d-sm-block">
                                <ul>
                                    <li><a href="php_files/logout.php"a class="d-none d-lg-block">Cerrar Sesion <i class="ti-lock"></i></a></li>
                                </ul>
                            </div>
                        </nav>
                    </div>
                </div>
            </div>
        </header>
        <!-- Header part end-->

        <!-- breadcrumb start-->
        <section class="breadcrumb breadcrumb_bg">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="breadcrumb_iner text-center">
                            <div class="breadcrumb_iner_item">
                                <h2>Agregar Empresa</h2>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- breadcrumb start-->

        <section>
            <div class="container mt-4">
                
                <form id="RegistroEmpresas" action="Registro_Empresas.php" method="post" data-toggle="validator" data-disable="false" class="popup-form" enctype="multipart/form-data" style="background-color: #fff;
                max-width: 1600px; margin: 20px auto 0; padding: 90px; color: #218838; box-shadow: 8px 8px 8px rgba(0,0,0,0.2);">
                    <div class="row">
                        <div     class="form-group col-sm-6">
                            <div class="help-block with-errors"></div>
                            <i class="fa fa-user"></i> <label for="foto"><strong>Imagen Empresa</strong></label>
                            <input name="foto" type="file" />


                        </div>

                        <div     class="form-group col-sm-6">
                            <div class="help-block with-errors"></div>
                            <i class="fa fa-user"></i> <label for="nomE"><strong> Nombre de Empresa</strong></label>
                            <input  type="text" placeholder="Nombre de Empresa" name="nomE" id="nombreE" class="form-control" value="" required="" />
                        </div>
                        <!-- end form-group -->
                        <div class="form-group col-sm-6">
                            <div class="help-block with-errors"></div>
                            <i class="fa fa-wrench"></i> <label for="CbotamañoE"><strong>Tamaño empresa</strong></label>
                            <select class="dropdown-item"  name="CbotamañoE"style="border: #000">
                                <option value="0">
                                    Selecciona una opcion
                                </option>
                                <option value="Pequeña">
                                    Pequeña
                                </option>
                                <option value="Mediana">
                                    Mediana
                                </option>
                                <option value="Grande">
                                    Grande
                                </option>
                            </select>
                           
                        </div>
                        <div class="form-group col-sm-6">
                            <div class="help-block with-errors"></div>
                            <i class="fa fa-user"></i> <label for="caract"><strong>Caracteristicas y  Requisitos</strong></label>
                            <textarea  type="text" placeholder="Caracteristicas de la empresa" name="caract" id="caract" class="form-control" value="" required=""></textarea>
                                

                        </div><!-- end form-group -->
                        <div class="form-group col-sm-6">
                            <div class="help-block with-errors"></div>
                            <i class="fa fa-users"></i> <label for="info"><strong>Información</strong></label>
                            <textarea  type="text" placeholder="Información de la empresa" name="info" id="genero" class="form-control" required="" value=""></textarea>
                                

                        </div><!-- end form-group -->





                        <div class="form-group col-sm-6">
                            <div class="help-block with-errors"></div>
                            <i class="fa fa-pass"></i> <label for="rfc"><strong>RFC</strong></label>
                            <input  type="text" placeholder="RFC Empresa" name="rfc" id="contraseña" required="" class="form-control" value=""/>

                        </div>


                        <div class="form-group col-sm-6">
                            <div class="help-block with-errors"></div>
                            <i class="fa fa-map "></i> <label for="ubicacion"><strong>Ubicación de la empresa</strong></label>
                                <input  type="text" placeholder="Ubicación" name="ubicacion" id="contraseña" required="" class="form-control" value=""/>
                        </div>
                        
                        <div class="form-group col-sm-6">
                            <div class="help-block with-errors"></div>
                            <i class="fa fa-map "></i> <label for="cbx_carrera"><strong>Carrera a la cual va enfocada</strong></label>
                            <select class="dropdown-item" style="border: #000" id="cbx_carrera" name="cbx_carrera">
                                <option value="0">
                                    Selecciona Carrera
                                </option>

                                <option value="2">
                                  Ingenieria En  Tecnologias de la Informacion y Comunicación
                                </option>
                                   <option value="3">
                                  Ingeniera en Administración de Capital Humano
                                </option>

                            </select>

                        </div>

                        <div class="form-group last col-sm-12" style="text-align: center;">
                            <button type="submit" name="btn" value="guardar" class="btn-block btn-success btn-lg">Enviar</button>
                        </div>
                        <div class="clearfix"></div>
                    </div><!-- end row -->
                </form><!-- end form -->
            </div>
            <img src="">
        </section>
        <br> <br>



        <!-- ================ contact section start ================= -->
        
        <!-- ================ contact section end ================= -->

        <!-- footer part start-->
         <footer class="footer-area">
            <div class="container">
                <center>
                <div class="row">
                    <div class="col-xl-4 col-md-4 col-sm-6">
                        <div class="single-footer-widget footer_1">
                            <img src="login/images/group digital logo_p.png" alt="">
                        </div>
                    </div>
                    <div class="col-xl-4 col-md-4 col-sm-6">
                        <div class="single-footer-widget footer_2">
                            <h4>Contactanos</h4>
                            <div class="contact_info">
                                <span class="ti-home"></span>
                                <h5>Av. Universidad Tecnológica</h5>
                                <p>#1000, Col.Tierra Negra Xicotepec de Juárez, Puebla C.P.73080</p>
                            </div>
                            <div class="contact_info">
                                <span class="ti-headphone-alt"></span>
                                <h5>01 (764) 764 5240 y 764 5252</h5>
                            </div>
                        </div>
                    </div>
                </div>
                </center>
                <div class="row align-items-center">
                    <div class="col-lg-12">
                        <div class="copyright_part_text text-center">
                            <p class="footer-text m-0"><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                                Copyright &copy;<script>document.write(new Date().getFullYear());</script> <i class="ti-heart" aria-hidden="true"></i> por <a href="https://colorlib.com" target="_blank">GROUP DIGITAL</a>
                                <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. --></p>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
        <!-- footer part end-->
     <?php
            }else{
                header("Location: http://localhost/ProyectoEstadias/Login.php ");
            }
            ?>
        <!-- jquery plugins here-->
        <!-- jquery -->
        <script src="js/jquery-1.12.1.min.js"></script>
        <!-- popper js -->
        <script src="js/popper.min.js"></script>
        <!-- bootstrap js -->
        <script src="js/bootstrap.min.js"></script>
        <!-- particles js -->
        <script src="js/contact.js"></script>
        <!-- ajaxchimp js -->
        <script src="js/jquery.ajaxchimp.min.js"></script>
        <!-- validate js -->
        <script src="js/jquery.validate.min.js"></script>
        <!-- form js -->
        <script src="js/jquery.form.js"></script>
        <script src="js/mail-script.js"></script>
        <!-- custom js -->
        <script src="js/custom.js"></script>
    </body>

</html>