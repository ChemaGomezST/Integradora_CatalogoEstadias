<!doctype html>
<?php
include '../php_files/lib_empresas.php';


if ($_POST) {
    if ($_POST['btn'] == "guardar") {

        $nombreEmp = $_POST['nombreEm'];
        $contacto = $_POST['contact'];
        $totalVac = $_POST['totalVa'];
        $usuarioId = $_POST['id_usuario'];
        $procesoId = $_POST['process'];
        GuardarProEmpresa($nombreEmp ,$contacto ,$totalVac,$usuarioId,$procesoId);
    } 
}
?>
<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">

    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <title>Estadias</title>
        <link rel="icon" href="img/favicon.png">
        <!-- Bootstrap CSS -->
        <link rel="stylesheet" href="../css/bootstrap.min.css">
        <!-- animate CSS -->
        <link rel="stylesheet" href="../css/animate.css">
        <!-- owl carousel CSS -->
        <link rel="stylesheet" href="../css/owl.carousel.min.css">
        <!-- themify CSS -->
        <link rel="stylesheet" href="../css/themify-icons.css">
        <!-- flaticon CSS -->
        <link rel="stylesheet" href="../css/liner_icon.css">
        <link rel="stylesheet" href="../css/search.css">
        <!-- swiper CSS -->
        <link rel="stylesheet" href="../css/slick.css">
        <!-- style CSS -->
        <link rel="stylesheet" href="../css/style.css">
    </head>
      <?php
        if (isset($_SESSION['Alumno'])) {
            ?>
    <body>
        <!--::header part start::-->
        <header class="main_menu">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-12">
                        <nav class="navbar navbar-expand-lg navbar-light">
                            <a class="navbar-brand" href="index.html"> <img src="../login/images/logo_p.png" alt="logo"> </a>
                            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
                                    aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                                <span class="navbar-toggler-icon"></span>
                            </button>

                            <div class="collapse navbar-collapse main-menu-item justify-content-center" id="navbarSupportedContent">
                                <ul class="navbar-nav">
                                    <li class="nav-item active">
                                        <a class="nav-link" href="../index3.php">Inicio</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="../indexEmpresa.php">Empresas</a>
                                    </li>
                                </ul>
                            </div>
                             <div class="header_social_icon d-none d-sm-block">
                                <ul>
                                    <li><a href="../php_files/logout.php"a class="d-none d-lg-block">Cerrar Sesión<i class="ti-lock"></i></a></li>
                                </ul>
                            </div>
                        </nav>
                    </div>
                </div>
            </div>
        </header>
        <!-- Header part end-->

        <!-- breadcrumb start-->
        <section class="breadcrumb breadcrumb_bg">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="breadcrumb_iner text-center">
                            <div class="breadcrumb_iner_item">
                                <h2>Propuesta de Empresa</h2>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- breadcrumb start-->

        <section>
            <br>
      
            <div class="container mt-4">
                <form  action="PropuestaEmpresa.php" method="post" class="popup-form">
                    <div class="row">
                        <div id="msgContactSubmit" class="hidden"></div>
                             <input  type="hidden"  name="id_usuario" id="id_usuario" class="form-control" value="<?php echo "".$_SESSION['usuario_id']."";?>"/>
                        <!-- end form-group -->
                        <div class="form-group col-sm-6">
                            <div class="help-block with-errors"></div>
                            <i class="fa fa-user"></i> <label for="nombreEm"><strong>Nombre de la empresa</strong></label>
                            <input  type="text" placeholder="Nombre empresa" name="nombreEm" id="nombreEm" class="form-control" value=""/>

                        </div><!-- end form-group -->
                        <div class="form-group col-sm-6">
                            <div class="help-block with-errors"></div>
                            <i class="fa fa-user"></i> <label for="contact"><strong>Contacto</strong></label>
                            <input  type="text" placeholder="Contacto" name="contact" id="contact" class="form-control" value=""/>

                        </div><!-- end form-group -->

                               <div class="form-group col-sm-6">
                            <div class="help-block with-errors"></div>
                            <i class="fa fa-user"></i> <label for="totalVa"><strong>Total vacantes</strong></label>
                            <input  type="text" placeholder="Total de vacantes" name="totalVa" id="totalVa" class="form-control" value=""/>

                        </div>
                         
                           
                           

                        
                         <div class="form-group col-sm-6">
                            <div class="help-block with-errors"></div>
                            <i class="fa fa-map "></i> <label for="process"><strong>Proceso y Periodo</strong></label>
                            <select class="dropdown-item" style="border: #000" id="process" name="process" >
                                <option value="0">
                                    Selecciona ubicacion
                                </option>

                                <option value="1">
                                  TSU. 2019-05-01-2019-08-31
                                </option>
                                <option value="2">
                                  Ingenieria. 2020-01-01-2020-01-01 
                                </option>
                                <option value="3">
                                  Licenciatura  2020-05-01-2020-08-31
                                </option>
                            </select>

                        </div>        
                            
                        <div class="form-group last col-sm-12" style="text-align: center;">
                            <button type="submit" name="btn" value="guardar" class="btn-block btn-success btn-lg">Enviar</button>
                        </div>
                       


                        <div class="clearfix"></div>
                    </div><!-- end row -->
                </form><!-- end form -->
            </div>
        </section>

        <footer class="footer-area">
            <div class="container">
                <center>
                <div class="row">
                    <div class="col-xl-4 col-md-4 col-sm-6">
                        <div class="single-footer-widget footer_1">
                            <img src="login/images/group digital logo_p.png" alt="">
                        </div>
                    </div>
                    <div class="col-xl-4 col-md-4 col-sm-6">
                        <div class="single-footer-widget footer_2">
                            <h4>Contactanos</h4>
                            <div class="contact_info">
                                <span class="ti-home"></span>
                                <h5>Av. Universidad Tecnológica</h5>
                                <p>#1000, Col.Tierra Negra Xicotepec de Juárez, Puebla C.P.73080</p>
                            </div>
                            <div class="contact_info">
                                <span class="ti-headphone-alt"></span>
                                <h5>01 (764) 764 5240 y 764 5252</h5>
                            </div>
                        </div>
                    </div>
                </div>
                </center>
                <div class="row align-items-center">
                    <div class="col-lg-12">
                        <div class="copyright_part_text text-center">
                            <p class="footer-text m-0"><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                                Copyright &copy;<script>document.write(new Date().getFullYear());</script> <i class="ti-heart" aria-hidden="true"></i> por <a href="https://colorlib.com" target="_blank">GROUP DIGITAL</a>
                                <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. --></p>
                        </div>
                    </div>
                </div>
            </div>
        </footer>

        <!-- footer part end-->
    <?php
    } else {
        header("Location: http://localhost/ProyectoEstadias/Login.php ");
    }
    ?>
        <!-- jquery plugins here-->
        <!-- jquery -->
        <script src="js/jquery-1.12.1.min.js"></script>
        <!-- popper js -->
        <script src="js/popper.min.js"></script>
        <!-- bootstrap js -->
        <script src="js/bootstrap.min.js"></script>
        <!-- particles js -->
        <script src="js/contact.js"></script>
        <!-- ajaxchimp js -->
        <script src="js/jquery.ajaxchimp.min.js"></script>
        <!-- validate js -->
        <script src="js/jquery.validate.min.js"></script>
        <!-- form js -->
        <script src="js/jquery.form.js"></script>
        <script src="js/mail-script.js"></script>
        <!-- custom js -->
        <script src="js/custom.js"></script>
    </body>

</html>
