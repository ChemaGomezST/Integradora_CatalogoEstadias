<!DOCTYPE html>

<html lang="en-US">
    <head>
        <meta charset="utf-8">
        <meta content="IE=edge" http-equiv="X-UA-Compatible">
        <meta name="viewport" content="width=device-width, minimum-scale=1, maximum-scale=1"/>
        <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->

        <title>Formulario de Asignación</title>
        <!-- set your website meta description and keywords -->
        <meta name="description" content="Add your business website description here">
        <meta name="keywords" content="Add your business website keywords here">
        <!-- set your website favicon -->
        <link href="favicon.html" rel="icon">	

        <!-- Bootstrap Stylesheets -->
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <!-- Font Awesome Stylesheets -->
        <link rel="stylesheet" href="css/font-awesome.min.css">
        <!-- Template Main Stylesheets -->
        <link rel="stylesheet" href="css/contact-form.css" type="text/css">	
    <header style="background-color: white;">
     <nav>
         
                <div class="container">
                    <div class="row">
                        <ul class="nav ml-auto">
                            <li class="nav-item">
                                <a href="../index3.php" class="nav-link">
                                    Inicio
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="../login/Login.php" class="nav-link">
                                   Login
                                </a>
                            </li>
                       
                                <li class="nav-item">
                                    <a class="nav-link" href="../formularios/Registro_Empresas.php">Registro de Empresas</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="../formularios/PropuestaEmpresa.php"> Propuesta de Estadia</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="../formularios/Registro.php"> Registro de Usuarios</a>
                                </li>
                           
                        </ul>
                    </div>
                </div>

            </nav>
</header>
    </head>

    <body>

        <section id="contact-form-section" class="form-content-wrap" >
            <div class="container"  >
                <div class="row" >
                    <div class="tab-content" >
                        <div class="col-sm-12">
                            <div class="item-wrap" style="background-color: white;">
                                <div class="row">

                                    <div class="col-sm-12">
                                        <div class="item-content colBottomMargin">
                                            <div class="item-info">
                                                <h2 class="item-title text-center">Formulario de Postulación</h2>

                                            </div><!--End item-info -->

                                        </div><!--End item-content -->
                                    </div><!--End col -->
                                    <div class="col-md-12">


                                        <form id="contactForm" action="Registro.php" method="post" name="contactform"  class="popup-form">
                                            <div class="row">
                                                <div id="msgContactSubmit" class="hidden"></div>

                                                <div     class="form-group col-sm-6">
                                                    <div class="help-block with-errors"></div>
                                                    <i class="fa fa-user"></i> <label for="nombre"><strong> Nombre Alumno</strong></label>
                                                    <input  type="text" placeholder="Nombre Alumno" name="nombre" id="nombre" class="form-control" value=""/>

                                                </div><!-- end form-group -->
                                                <div class="form-group col-sm-6">
                                                    <div class="help-block with-errors"></div>
                                                    <i class="fa fa-user"></i> <label for="apa"><strong>Matriucula</strong></label>
                                                    <input  type="text" placeholder="Matriucla" name="apa" id="apa" class="form-control" value=""/>

                                                </div><!-- end form-group -->
                                                <div class="form-group col-sm-6">
                                                    <div class="help-block with-errors"></div>
                                                    <i class="fa fa-calendar-check-o"></i> <label for="ama"><strong>Carrera</strong></label>
                                                    <input  type="text" placeholder="Carrera" name="ama" id="apa" class="form-control" value=""/>

                                                </div><!-- end form-group -->
                                                <div class="form-group col-sm-6">
                                                    <div class="help-block with-errors"></div>
                                                    <i class="fa fa-calendar-check-o"></i> <label for="genero"><strong>Numero Seguro Social</strong></label>
                                                    <input  type="text" placeholder="Numero de Seguro" name="genero" id="genero" class="form-control" value=""/>

                                                </div><!-- end form-group -->
                                                <div class="form-group col-sm-6">
                                                    <div class="help-block with-errors"></div>
                                                    <i class="fa fa-calendar-check-o"></i> <label for="fechaNa"><strong>Curriculum </strong></label>
                                                    <input  type="file" placeholder="Fecha de Fin" name="fechaNa" id="fechaNa" class="form-control" value=""/>
                                                      
                                                </div>
                                                
                                                 <div class="form-group last col-sm-12" style="text-align: center;">
                                                    <button type="submit" name="btn" value="guardar" class="btn-block btn-success btn-lg">Enviar</button>
                                                </div>
                                                <div class="clearfix"></div>
                                            </div><!-- end row -->
                                        </form><!-- end form -->






                                    </div>
                                </div><!--End row -->


     

                                <!-- Popup end -->

                            </div><!-- end item-wrap -->
                            <table class="table table-hover" style="background-color: white;">
                             <thead>
                                 <tr>
                                     <td>Accion</td>
                                     <td>Aprobación</td>
                                     <td>Quien lo Aprueba</td>
                                     <td>Fecha Aprobación</td>
                                     <td>Fecha Inicio</td>
                                     <td>Fecha de Fin</td>
                                    
                                 </tr>
                             </thead>
                             <tbody>
                               
                                 
                                 <!--arreglo asociativo-->
                         
                           
                      
                          
                     
                             </tbody>
                         </table>
                        </div><!--End col -->
                    </div><!--End tab-content -->
                </div><!--End row -->
            </div><!--End container -->
        </section>












        <div class="colBottomMargin">
            &nbsp;<div class="colBottomMargin">&nbsp;</div>
        </div>	

   

        <a href="#" class="scrollup"><i class="fa fa-arrow-circle-up"></i></a>

        <!-- jQuery Library -->
        <script src="js/jquery-3.2.1.min.js"></script>	
        <!-- Popper js -->
        <script src="js/popper.min.js"></script>
        <!-- Bootstrap Js -->
        <script src="js/bootstrap.min.js"></script>
        <!-- Form Validator -->
        <script src="js/validator.min.js"></script>
        <!-- Contact Form Js -->
        <script src="js/contact-form.js"></script>

    </body>
</html>
