<!DOCTYPE html>
<?php
include '../php_files/libreria.php';
if ($_POST) {
    if ($_POST['btn'] == "guardar") {
        $nombreU = $_POST['nomU'];
        $correo = $_POST['email'];
        $contraseña = $_POST['psw'];
        $estatus = $_POST['estatus'];
        $persona = $_POST['per'];
        GuardarUsuario($nombreU ,$correo ,$contraseña ,$estatus,$persona);
    }
}
?>
<html lang="en-US">
    <head>
        <meta charset="utf-8">
        <meta content="IE=edge" http-equiv="X-UA-Compatible">
        <meta name="viewport" content="width=device-width, minimum-scale=1, maximum-scale=1"/>
        <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->

        <title>Formulario de Registro de Usuarios</title>
        <!-- set your website meta description and keywords -->
        <meta name="description" content="Add your business website description here">
        <meta name="keywords" content="Add your business website keywords here">
        <!-- set your website favicon -->
        <link href="favicon.html" rel="icon">	

        <!-- Bootstrap Stylesheets -->
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <!-- Font Awesome Stylesheets -->
        <link rel="stylesheet" href="css/font-awesome.min.css">
        <!-- Template Main Stylesheets -->
        <link rel="stylesheet" href="css/contact-form.css" type="text/css">	
    <header style="background-color: white;">
     <nav>
                <div class="container">
                    <div class="row">
                        <ul class="nav ml-auto">
                            <li class="nav-item">
                                <a href="../index.php" class="nav-link">
                                    Inicio
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="../login/Login.php" class="nav-link">
                                   Login
                                </a>
                            </li>
                             <li class="nav-item">
                                 <a href="../formularios/PropuestaEmpresa.php" class="nav-link">
                                   Propuesta Empresa
                                </a>
                            </li>
                             <li class="nav-item">
                                 <a href="../formularios/Registro_Asignación.php" class="nav-link">
                                  Registro Asignación
                                </a>
                            </li>
                             <li class="nav-item">
                                 <a href="../formularios/Registro_Empresas.php" class="nav-link">
                                   Registro Empresa
                                </a>
                            </li>
                           
                        </ul>
                    </div>
                </div>

            </nav>
</header>
    </head>

    <body>

        <section id="contact-form-section" class="form-content-wrap" >
            <div class="container"  >
                <div class="row" >
                    <div class="tab-content" >
                        <div class="col-sm-12">
                            <div class="item-wrap" style="background-color: white;">
                                <div class="row">

                                    <div class="col-sm-12">
                                        <div class="item-content colBottomMargin">
                                            <div class="item-info">
                                                <h2 class="item-title text-center">Formulario de Registro de Usuarios</h2>

                                            </div><!--End item-info -->

                                        </div><!--End item-content -->
                                    </div><!--End col -->
                                    <div class="col-md-12">


                                        <form id="contactForm" action="Registro.php" method="post" name="contactform"  class="popup-form">
                                            <div class="row">
                                                <div id="msgContactSubmit" class="hidden"></div>
                                                
                                   
                                                <div     class="form-group col-sm-6">
                                                    <div class="help-block with-errors"></div>
                                                    <i class="fa fa-user"></i> <label for="nomU"><strong>Ingrese de Usuario</strong></label>
                                                    <input  type="text" placeholder="Nombre Usuario" name="nomU" id="nomU" class="form-control" value=""/>

                                                </div><!-- end form-group -->
                                                <div class="form-group col-sm-6">
                                                    <div class="help-block with-errors"></div>
                                                    <i class="fa fa-user"></i> <label for="email"><strong>Correo</strong></label>
                                                    <input  type="text" placeholder="Correo" name="email" id="email" class="form-control" value=""/>

                                                </div><!-- end form-group -->
                                                <div class="form-group col-sm-6">
                                                    <div class="help-block with-errors"></div>
                                                    <i class="fa fa-user"></i> <label for="psw"><strong>Contraseña</strong></label>
                                                    <input  type="text" placeholder="Contraseña" name="psw" id="psw" class="form-control" value=""/>

                                                </div><!-- end form-group -->
                                                
                                                <div class="form-group col-sm-6">
                                                    <div class="help-block with-errors"></div>
                                                    <i class="fa fa-calendar"></i> <label for="estatus"><strong>Estatus</strong></label>
                                                    <input  type="text" placeholder="Estatus" name="estatus" id="estatus" class="form-control" value=""/>

                                                </div>
                                                 <div class="form-group col-sm-6">
                                                    <div class="help-block with-errors"></div>
                                                    <i class="fa fa-calendar"></i> <label for="per"><strong>Persona</strong></label>
                                                    <input  type="text" placeholder="Nmbre Personsa" name="per" id="per" class="form-control" value=""/>

                                                </div>
                                                
                                                
                                               <div class="form-group last col-sm-12" style="text-align: center;">
                                                    <button type="submit" name="btn" value="guardar" class="btn-block btn-success btn-lg">Enviar</button>
                                                </div>
                                                
                                          
                                               
                                                <div class="clearfix"></div>
                                            </div><!-- end row -->
                                        </form><!-- end form -->






                                    </div>
                                </div><!--End row -->




                                <!-- Popup end -->

                            </div><!-- end item-wrap -->
                            <table class="table table-hover" style="background-color: white;">
                             <thead>
                                 <tr>
                                     <td>Accion</td>
                                     <td>Nombre</td>
                                     <td>A.Paterno</td>
                                     <td>A.Materno</td>
                                     <td>Genero</td>
                                     <td>Fecha Nacimiento</td>
                                     <td>Pais</td>
                                     <td>Correo</td>
                                     <td>Contraseña</td>
                                     <td>Tipo de usuario</td>
                                     <td>Carrera</td>
                                 </tr>
                             </thead>
                             <tbody>
                               
                                 
                                 <!--arreglo asociativo-->
                         
                           
                      
                          
                     
                             </tbody>
                         </table>
                        </div><!--End col -->
                    </div><!--End tab-content -->
                </div><!--End row -->
            </div><!--End container -->
        </section>












        <div class="colBottomMargin">
            &nbsp;<div class="colBottomMargin">&nbsp;</div>
        </div>	

    

        <a href="#" class="scrollup"><i class="fa fa-arrow-circle-up"></i></a>

        <!-- jQuery Library -->
        <script src="js/jquery-3.2.1.min.js"></script>	
        <!-- Popper js -->
        <script src="js/popper.min.js"></script>
        <!-- Bootstrap Js -->
        <script src="js/bootstrap.min.js"></script>
        <!-- Form Validator -->
        <script src="js/validator.min.js"></script>
        <!-- Contact Form Js -->
        <script src="js/contact-form.js"></script>

    </body>
</html>
