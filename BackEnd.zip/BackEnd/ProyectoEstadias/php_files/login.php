<?php
require_once("./libreria.php");
$correo=$_POST['correo'];
$contraseña=$_POST['contraseña'];
$result=valida_usuario($correo, $contraseña);
$datos = $result->fetch_assoc();
if(!empty($datos)){
    session_start();
    switch ($datos["tipo_usuario"]) {
        case 'Personal':
            $_SESSION['Personal']=TRUE;
            header("Location: http://localhost/ProyectoEstadias/index2.php");

            break;
         case 'Alumno':
            $_SESSION['Alumno']=TRUE;
            header("Location: hhttp://localhost/ProyectoEstadias/index3.php");

            break;
          case 'UsuarioNormal':
            $_SESSION['UsuarioNormal']=TRUE;
            header("Location: http://localhost/ProyectoEstadias/index1.php ");

            break;
        default:
            break;
    }
    }else{
        echo 'usuario no existe';
    }
?>
