<?php
function Conectar(){
    $con=new mysqli("localhost", "root","1234", "bd_estadia");
    $con->query("SET NAMES 'utf8'");
    return $con;
}
?>

