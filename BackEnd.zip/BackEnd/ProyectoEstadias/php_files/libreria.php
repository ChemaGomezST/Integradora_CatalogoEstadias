<?php
include 'Conecta.php';
function GuardarUsuario($nombreU ,$correo ,$contraseña ,$estatus,$persona,$tipo_usuario){
    $sql="insert into usuario (nombre_usuario,correo,contraseña,estatus,personas_id,tipo_usuario)  values ('".$nombreU."','".$correo."','".$contraseña."','".$estatus."',".$persona.",'".$tipo_usuario."');";
    $con= Conectar();
    $con->query($sql);
    $con->close();
    echo "<script type='text/javascript'>alert('Datos guardados en la BD');</script>";
    
    
}
function valida_usuario($correo,$contraseña){
    $sql="select * from usuario where correo='".$correo."' and contraseña='".$contraseña."'";
    $con=  Conectar();
    $result= $con->query($sql);
    return $result;
}

 
?>
