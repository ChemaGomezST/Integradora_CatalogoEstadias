package com.example.login_apk;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.net.URI;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

public class bienvenidoAlumno extends AppCompatActivity {

    EditText nombreEmp,tamañoEmp,caractEmp,infoEmp,rfcEmp,dirEmp;
    Button btn_registrar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bienvenido_alumno);
        nombreEmp=(EditText)findViewById(R.id.nombreEmp);
        tamañoEmp=(EditText)findViewById(R.id.tamañoEmp);
        caractEmp=(EditText)findViewById(R.id.caractEmp);
        infoEmp=(EditText)findViewById(R.id.infoEmp);
        rfcEmp=(EditText)findViewById(R.id.rfcEmp);
        dirEmp=(EditText)findViewById(R.id.dirEmp);
        btn_registrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ejecutarServicio("http://192.168.43.212/ProyectoEstadias/php_files/insertaEmpresa.php");
            }
        });
    }

    private void ejecutarServicio(String URL){

        StringRequest StringRequest=new StringRequest(Request.Method.POST, URL, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Toast.makeText(getApplicationContext(), "Operacion exitosa", Toast.LENGTH_SHORT).show();
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(),error.toString(),Toast.LENGTH_SHORT).show();
            }
        }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String,String> parametros=new HashMap<String, String>();
                parametros.put("nombreEmp",nombreEmp.getText().toString());
                parametros.put("tamañoEmp",tamañoEmp.getText().toString());
                parametros.put("caractEmp",caractEmp.getText().toString());
                parametros.put("infoEmp",infoEmp.getText().toString());
                parametros.put("rfcEmp",rfcEmp.getText().toString());
                parametros.put("dirEmp",dirEmp.getText().toString());
                return parametros;
            }
        };
        RequestQueue requestQueue= Volley.newRequestQueue( this);
        requestQueue.add(StringRequest);
    }
}
