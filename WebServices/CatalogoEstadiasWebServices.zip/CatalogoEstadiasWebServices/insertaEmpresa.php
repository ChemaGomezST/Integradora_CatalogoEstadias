<?php
include './Conecta.php';
$imgEmpresa="fotos/login.png";
$nombre_e=$_POST['nombreEmp'];
$tamañoEmp=$_POST['tamañoEmp'];
$caractEmp=$_POST['caractEmp'];
$infoEmp=$_POST['infoEmp'];
$vinculaEmp="En Proceso";
$rfcEmp=$_POST['rfcEmp'];
$total_vacantesEmpresa=0;
$estatusEmpresa="En Proceso";
$carrera_id=1;
$direccion=$_POST['dirEmp'];

//
//
//$imgEmpresa="fotos/IMSS.jpg";
//$nomEmpresa="nombre_e";
//$tamañoEmpresa="Mediana";
//$caracterEmpresa="Muy grande";
//$infoEmpresa="Nececitamos Esclavos";
//$vinculaEmp="En Proceso";
//$rfcEmpresa="MLDASDAS";
//$total_vacantesEmpresa=0;
//$estatusEmpresa="En Proceso";
//$ubicacion=1;
//$carrera=1;


    $sql = "INSERT INTO empresas (imagen_empresa,nombre_e,Tamaño,Caracteristicas,Informacion,Vinculada,RFC, total_vacantes,estatus,carreras_id,fecha_upload,ubicacion) values('".$imgEmpresa."','".$nombre_e."','".$tamañoEmp."','".$caractEmp."','".$infoEmp."','".$vinculaEmp."','".$rfcEmp."',".$total_vacantesEmpresa.",'".$estatusEmpresa."',".$carrera_id.",NOW(),'".$direccion."');";
    $con= Conectar();
    $con->query($sql);
    $con->close();
    echo $sql;
    ?>